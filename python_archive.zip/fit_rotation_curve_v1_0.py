#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Created on Tues Jul 17 2018
@author: Jacob A. Smith
@version: 1.0

Extracts rotation curve data points from files written with rotation_curve_vX_X
and fits a function to the data given several parameters.
"""
###############################
# Optional import statements  #
#    for diagnostics.         #
###############################
#import matplotlib.pyplot as plt
#import os.path

import glob
from astropy.io import ascii

import numpy as np
from scipy.optimize import curve_fit

from astropy.table import QTable, Column
import astropy.units as u


def fit_func( depro_radius, v_max, r_turn, alpha):
    """Function in which to fit the rotation curve data to.
    
    @param:
        depro_radius:
            float representation of the deprojected radius as taken from the 
            [PLATE]-[FIBERID] rotation curve data file (in units of kpc); the
            "x" data of the rotation curve equation
        
        v_max:
            the maximum velocity (or in the case of fitting the minimum, the 
            absolute value of the minimum velocity) parameter of the rotation
            curve equation (given in m/s)
            
        r_turn:
            the radius at which the rotation curve trasitions from increasing
            to flat-body parameter for the rotation curve equation (given in
            kpc)
            
        alpha:
            the exponential parameter for the rotation curve equation 
            (unitless)
            
    @return: the rotation curve equation with the given '@param' parameters and
             'depro_radius' data
            
    """
    return v_max * \
           (depro_radius / (r_turn**alpha + depro_radius**alpha)**(1/alpha))

def extract_data( LOCAL_PATH, ROT_CURVE_MASTER_FOLDER):
    """Extract the rotation curve data from the various data files as processed
    in 'rotation_curve_vX_X.'
    
    @param:
        LOCAL_PATH:
            string representation of the directory path of this file
            
        ROT_CURVE_MASTER_FOLDER:
            string representation of the path of the folder containing all of 
            the rotation curve data for all of the galaxies in the MaNGA survey
            
    @return:
        files:
            a string list containing all of the data files within the 
            'rotation_curve_vX_X' output folder
    """
    files = glob.glob( LOCAL_PATH + ROT_CURVE_MASTER_FOLDER + '/*/*')

    ###########################################################################
    # Code to isolate a file and run it within the loop for diagnostics.
    #
    # 'file_name_in_question' is the string name of the file being isolated
    #    whereas 'file_isolated' is the single-element list of this file name.
    ###########################################################################
#     file_name_in_question = files['INDEX']
#     file_isolated = []
#     file_isolated.append( file_name_in_question)
    ###########################################################################
    
    return files

def fit_data_files( files, TRY_N):
    """Finds the function of the line of best fit TRY_N times for the rotation 
    curve data file in question.
    
    @param:
        files:
            a string list containing all of the data files within the 
            'rotation_curve_vX_X' output folder
            
        TRY_N:
            int number of times to try finding the equation of the line of best
            fit before generating a timeout error (see scipy.optimize.curve_fit
            documentation linked below for more information).
            
    @return:
        best_fit_param_table:
            QTable containing the best fit parameters for each galaxy
    """
    
    v_max_best_master = []
    r_turn_max_best_master = []
    alpha_max_best_master = []
    v_min_best_master = []
    r_turn_min_best_master = []
    alpha_min_best_master = []
    
    idx_file_in_q = 0       # index of the file in question
    for data_file in files:
        #######################################
        #                                     #
        #     IMPORT DATA FROM DATA FILES     #
        #                                     #
        #######################################
        data_table = ascii.read(data_file, format='ecsv')
        depro_radii = data_table['Deprojected Distance'].value
        rot_vel_max = data_table['Max Velocity'].value
        rot_vel_min = data_table['Min Velocity'].value
    
        #######################################################################
        # General information about the data file in question as well as a plot
        #    of the data before fitting.  
        #######################################################################
#            print( data_file, ":\n\n", data_table, "\n\n")
#            print("DATA TABLE INFORMATION \n",
#                  'Columns:', data_table.columns, '\n',
#                  'Column Names:', data_table.colnames, '\n',
#                  'Meta Data:', data_table.meta, '\n',
#                  'Number of Rows:', len( data_table))
#               
#            plt.figure(10)
#            plt.plot( data_table['Deprojected Distance'], 
#                     data_table['Max Velocity'], 'ro')
#            plt.plot( data_table['Deprojected Distance'], 
#                     data_table['Min Velocity'], 'bo')
#            plt.ylabel('Deprojected Velocity (m/s)')
#            plt.xlabel('Deprojected Radius (kpc)')
#            plt.show()  
        #######################################################################
    
        #######################################################################
        # Create a set of conditions to test for valid data:
        #
        # I.)  The data file should contain at least three data points so as to
        #      fit a rotation curve.
        # II.) The absolute maximum and absolute minimum of each data file
        #      should not be 0.
        #######################################################################
        if len( data_table) >= 3:
            ###################################################################
            # Print the name of the data file in question to keep track of
            #    output.
            ###################################################################
#            print( os.path.split( data_file)[1])
            ###################################################################
        
            ###################################################################
            # Following from 'fit_func,' the following first guesses of the 
            #    parameters 'v_max,' 'r_turn,' and 'alpha' are described as
            #    such:
            #
            # v_max_guess / v_min_guess: 
            #    the absolute maximum and absolute minimum (respectively) of 
            #    the data file in question; first guess of the 'v_max' 
            #    parameter
            #
            # r_turn_max_guess / r_turn_min_guess: 
            #    the radius atwhich 'v_max' and 'v_min' are respectively found;
            #    first guess for 'r_turn' parameter
            #    
            # alpha_guess: imperically-estimated, first guess of the 'alpha'
            #    parameter
            ###################################################################
            v_max_guess = max( rot_vel_max)
            v_min_guess = max( rot_vel_min)
        
            if v_max_guess != 0 and v_min_guess != 0:
                r_turn_max_guess = depro_radii[
                        np.argwhere( rot_vel_max == v_max_guess)][0][0]
                r_turn_min_guess = depro_radii[
                        np.argwhere( rot_vel_min == v_min_guess)][0][0]
            
                alpha_guess = 2
    
                guess_max = [v_max_guess, r_turn_max_guess, alpha_guess]
                guess_min = [v_min_guess, r_turn_min_guess, alpha_guess]
    
                ###############################################################
                # Print statement to track the first guesses for the 'fit_func'
                #    parameters.
                ###############################################################
#                print("Max Parameter Guess:", guess_max)
#                print("Min Parameter Guess:", guess_min)
                ###############################################################
            
                ###################################
                #                                 #
                #     FIT DATA VIA 'FIT_FUNC'     #
                #                                 #
                ###################################
                ###############################################################
                # Each respective popt holds a 3X1 array of the best fit
                #    parameters for the data file in question.
                #
                # Each respective pcov holds the covarience matrix of the
                #    parameters for the data file in question.
                #
                # bounds: imperically-devised limits for 'fit_func'
                #
                # max_nfev: the number of times the algorithm will try to fit 
                #    the data
                #
                # loss='cauchy': "Severely weakens outliers influence, but may
                #    cause difficulties in optimization process"
                #    (see link below). 
                #
                # <docs.scipy.org/doc/scipy/reference/generated/
                # scipy.optimize.least_squares.html#scipy.optimize.least_squares>
                #
                # The statements below try to fit the data with 'fit_func' as
                #    defined above. If scipy.optimize.curve_fit hits the max
                #    number of times to fit the data, the best fit parameters
                #    are all set to -999.
                ###############################################################
                
                try:
                    popt_max, pcov_max = curve_fit( fit_func, 
                                                   depro_radii, rot_vel_max,
                                                   p0 = guess_max,
                                                   bounds=(
                                                        ( v_max_guess / 2, 
                                                          r_turn_max_guess / 4, 
                                                          0),
                                                        ( v_max_guess * 1.5, 
                                                          r_turn_max_guess * 2, 
                                                          np.inf)),
                                                 max_nfev=TRY_N, loss='cauchy')
                                           
                    popt_min, pcov_min = curve_fit( fit_func, 
                                                   depro_radii, rot_vel_min, 
                                                   p0 = guess_min,
                                                   bounds=(
                                                        ( v_min_guess / 2,
                                                          r_turn_min_guess / 4,
                                                          0), 
                                                        ( v_min_guess * 1.5, 
                                                          r_turn_min_guess * 2, 
                                                          np.inf)),
                                                 max_nfev=TRY_N, loss='cauchy')
                                                        
                    v_max_best = popt_max[0]
                    r_turn_max_best = popt_max[1]
                    alpha_max_best = popt_max[2]
        
                    v_min_best = popt_min[0]
                    r_turn_min_best = popt_min[1]
                    alpha_min_best = popt_min[2]
            
                except RuntimeError:
                    v_max_best = -999
                    r_turn_max_best = -999
                    alpha_max_best = -999
        
                    v_min_best = -999
                    r_turn_min_best = -999
                    alpha_min_best = -999
                                               
                ###############################################################
                # Print statement to track the best fit parameters for the data
                #    file in question as well as code to plot the data file in
                #    question along with the line of best fit.
                ###############################################################
#                print( popt_max)
#                print( popt_min)
#                print('\n')
            
#                plt.figure(20)
#                plt.plot( data_table['Deprojected Distance'],
#                         data_table['Max Velocity'], 'ro')
#                plt.plot( data_table['Deprojected Distance'],
#                         data_table['Min Velocity'], 'bo')
#                plt.plot( np.linspace( 0, depro_radii[-1], 10000),
#                         fit_func(np.linspace( 0, depro_radii[-1], 10000),
#                                  popt_max[0], popt_max[1], popt_max[2]), 
#                                  'r--')
#                plt.plot( np.linspace( 0, depro_radii[-1], 10000),
#                         fit_func(np.linspace( 0, depro_radii[-1], 10000),
#                                  popt_min[0], popt_min[1], popt_min[2]), 
#                                  'b-.')
#                plt.ylabel('Deprojected Velocity (m/s)')
#                plt.xlabel('Deprojected Radius (kpc)')
#                plt.show()
            
#                print("Index in 'files':", idx_files)
#                print("-----------------------------------------------------")
                ###############################################################
            
        #######################################################################
        # If the data file in question has less than three data points, assign
        #    the output as 'None.'
        #######################################################################
        elif len( data_table) < 3:
            ###################################################################
            # Print statement to track the files that have less than three data
            #    points. Also prints the index of the file within the 'files'
            #    list.
            ###################################################################
#            print( os.path.split( data_file)[1], "[", idx_files, "]", 
#                  ": NO SUFFICENT DATA FOUND \n\n")
            ###################################################################
            v_max_best = None
            r_turn_max_best = None
            alpha_max_best = None
        
            v_min_best = None
            r_turn_min_best = None
            alpha_min_best = None

        #######################################################################
        # If either the absolute maximum or the absolute minimum of the data
        #    file in question is zero, assign the alpha_best  as 'None' and the
        #    remaining parameters as '-1' as to differentiate between the 
        #    insufficent data condition as shown above.
        #######################################################################
        elif v_max_guess == 0 or v_min_guess == 0:
            ###################################################################
            # Print statement to track the files where either 'v_max_guess' or 
            #    'v_min_guess' equal zero. Also prints the index of the file
            #    within the 'files' list.
            ###################################################################
#            print( os.path.split( data_file)[1], "[", idx_files, "]", 
#                  ": BAD DATA FILE {absolute max/min velocity = 0} \n\n")
            ###################################################################
            v_max_best = -1
            r_turn_max_best = -1
            alpha_max_best = None
        
            v_min_best = -1
            r_turn_min_best = -1
            alpha_min_best = None
        
        v_max_best_master.append( v_max_best)
        r_turn_max_best_master.append( r_turn_max_best)
        alpha_max_best_master.append( alpha_max_best)
        v_min_best_master.append( v_min_best)
        r_turn_min_best_master.append( r_turn_min_best)
        alpha_min_best_master.append( alpha_min_best)
                                     
        idx_file_in_q += 1
        
        
        
    v_max_best_col = Column( v_max_best_master)
    r_turn_max_best_col = Column( r_turn_max_best_master)
    alpha_max_best_col = Column( alpha_max_best_master)
    v_min_best_col = Column( v_min_best_master)
    r_turn_min_best_col = Column( r_turn_min_best_master)
    alpha_min_best_col = Column( alpha_min_best_master)
        
    best_fit_param_table = QTable([ v_max_best_col * (u.m / u.s),
                                    r_turn_max_best_col * u.kpc,
                                    alpha_max_best_col,
                                    v_min_best_col * (u.m / u.s),
                                    r_turn_min_best_col * u.kpc,
                                    alpha_min_best_col],
                           names = ['Max Velocity Best Fit',
                                    'Turnover Radius Max Best Fit',
                                    'Alpha Max Best Fit',
                                    'Min Velocity Best Fit',
                                    'Turnover Radius Min Best Fit',
                                    'Alpha Min Best Fit'])  
    
    return best_fit_param_table


def write_master_file( best_fit_param_table, 
                      LOCAL_PATH, MASTER_FILE_NAME):
    """Writes the list of galaxies along with the respective best fit
    parameters to a text file indicated in the 'MASTER_FILE_NAME' variable.
    
    @param:
        files:
            string list of galaxies for which curve fit analysis has been done
            
        best_fit_param_table:
            astropy QTable that contains:
                i.) MaNGA plate and fiberID for identification
               ii.) the best fit parameters for the max and min rotation
                       curves
        
        LOCAL_PATH:
            string representation of the directory path of this file
            
        MASTER_FILE_NAME:
            string representation of the name of the file which 
            'best_fit_param_table' will be written to
            
    @return: function returns the boolean True upon completion
    """
    
    master_table = ascii.read(LOCAL_PATH + MASTER_FILE_NAME, 
                              format='ecsv')
    
    master_table.add_column( best_fit_param_table['Max Velocity Best Fit'])
    master_table.add_column( best_fit_param_table['Turnover Radis Max Best Fit'])
    master_table.add_column( best_fit_param_table['Alpha Max Best Fit'])
    master_table.add_column( best_fit_param_table['Min Velocity Best Fit'])
    master_table.add_column( best_fit_param_table['Turnover Radis Min Best Fit'])
    master_table.add_column( best_fit_param_table['Alpha Min Best Fit'])
    
    ascii.write(master_table,
                LOCAL_PATH + MASTER_FILE_NAME,
                format = 'ecsv',
                overwrite = True)
    
    return True