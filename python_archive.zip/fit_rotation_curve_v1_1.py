#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Created on Tues Jul 17 2018
@author: Jacob A. Smith
@version: 1.1

Extracts rotation curve data points from files written with rotation_curve_vX_X
and fits a function to the data given several parameters.
"""
###############################
# Optional import statements  #
#    for diagnostics.         #
###############################
import matplotlib.pyplot as plt
import numpy as np

import glob, os.path

from scipy.optimize import curve_fit

from astropy.table import QTable, Column
from astropy.io import ascii
import astropy.units as u
import astropy.constants as const

def rot_fit_func( depro_radius, v_max, r_turn, alpha):
    """Function in which to fit the rotation curve data to.
    
    @param:
        depro_radius:
            float representation of the deprojected radius as taken from the 
            [PLATE]-[FIBERID] rotation curve data file (in units of kpc); the
            "x" data of the rotation curve equation
        
        v_max:
            the maximum velocity (or in the case of fitting the minimum, the 
            absolute value of the minimum velocity) parameter of the rotation
            curve equation (given in m/s)
            
        r_turn:
            the radius at which the rotation curve trasitions from increasing
            to flat-body parameter for the rotation curve equation (given in
            kpc)
            
        alpha:
            the exponential parameter for the rotation curve equation 
            (unitless)
            
    @return: the rotation curve equation with the given '@param' parameters and
             'depro_radius' data
            
    """
    return v_max * \
           (depro_radius / (r_turn**alpha + depro_radius**alpha)**(1/alpha))
           
#def lum_core_fit_func( depro_radius, lum_center, scale_rad_core):
#    """Function in which to fit the luminosity data to from the center to the
#    galaxy's 'core boundary.'
#    
#    @param:
#        depro_radius:
#            float representation of the deprojected radius as taken from the 
#            [PLATE]-[FIBERID] rotation curve data file (in units of kpc); the
#            "x" data of the rotation curve equation
#            
#        lum_center:
#            the light intensity at the theoretical center of the galaxy which
#            is taken to be the brightest point in the file
#            
#        scale_radius_core:
#            scale radius of the galaxy in question for the luminosity function
#            for the core of the galaxy
#            
#    @return:
#        the luminosity curve function for the buldge with the given '@param' 
#        parameters and 'depro_radius' data
#    """
#    
#    return lum_center * np.exp( -1 * (depro_radius / scale_rad_core)**(1/4))

def lum_fit_func_disk( depro_radius, lum_center, scale_rad_disk):
    """Function in which to fit the luminosity data to from the galaxy's 'core
    boundary' to the disk of the galaxy.
    
    @param:
        depro_radius:
            float representation of the deprojected radius as taken from the 
            [PLATE]-[FIBERID] rotation curve data file (in units of kpc); the
            "x" data of the rotation curve equation
            
        lum_center:
            the light intensity at the theoretical center of the galaxy which
            is taken to be the brightest point in the file
            
        scale_radius_disk:
            scale radius of the galaxy in question for the luminosity funciton
            for the disk of the galaxy
            
    @return:
        the luminosity curve function for the disk with the given '@param' 
        parameters and 'depro_radius' data
    """
    
    return lum_center * np.exp( -1*depro_radius / scale_rad_disk)

def lum_fit_func_sup( depro_radius, lum_center, scale_rad_core, scale_rad_disk):
    """Function in which the entirety of the luminosity vs radius data is fit.
    
    @param:
        depro_radius:
            float representation of the deprojected radius as taken from the 
            [PLATE]-[FIBERID] rotation curve data file (in units of kpc); the
            "x" data of the rotation curve equation
            
        lum_center:
            the light intensity at the theoretical center of the galaxy which
            is taken to be the brightest point in the file
            
        lum_core_edge:
            the light intensity at the boundary where the core of the galaxy
            transitions to the disk of the galaxy
            
        scale_radius:
            scale radius of the galaxy in question to be fitted
            
    @return:
        the luminosity curve function for the entirety of the galaxy with
        the given '@param' parameters and depro_radius data
    """
    
    #print(lum_center)
    #print(scale_rad_core)
    
    return lum_center * ( np.exp( -1*( depro_radius / scale_rad_core)**(1/4)) \
                        + np.exp( -1*depro_radius / scale_rad_disk) )

def fit_data_files( rot_curve_files, gal_stat_files,
                   TRY_N, ROT_IMAGE_DIR,
                   ROT_CURVE_MASTER_FOLDER, LOCAL_PATH):
    """Finds the function of the line of best fit TRY_N times for the rotation 
    curve data file in question.
    
    @param:
        rot_curve_files:
            a string list containing all of the rotation curve files within the 
            'rotation_curve_vX_X' output folder
            
        gal_stat_files:
            a string list containing all of the galaxy statistic files within
            the 'rotation_curve_vX_X' output folder
            
        TRY_N:
            int number of times to try finding the equation of the line of best
            fit before generating a timeout error (see scipy.optimize.curve_fit
            documentation linked below for more information).
            
    @return:
        best_fit_param_table:
            QTable containing the best fit parameters for each galaxy
    """
    ###########################################################################
    # Master arrays initialized to be empty.
    ###########################################################################
    v_max_best_master = []
    r_turn_best_master = []
    alpha_best_master = []
    
    v_max_sigma_master = []
    r_turn_sigma_master = []
    alpha_sigma_master = []
    chi_square_rot_master = []
    
    
#    lum_center_max_best_master = []
#    scale_rad_disk_max_best_master = []
#    lum_center_min_best_master = []
#    scale_rad_disk_min_best_master = []  
    
#    lum_center_max_sigma_master = []
#    scale_rad_disk_max_sigma_master = []
#    lum_center_min_sigma_master = []
#    scale_rad_disk_min_sigma_master = []
#    chi_square_lum_max_master = []
#    chi_square_lum_min_master = []
    
    infeasible_x0 = []
    
    for rot_file, gal_stat_file in zip( rot_curve_files, gal_stat_files):
        #######################################################################
        # Best fit parameters and errors in those parameters are initialized to
        # -1 to indicate that they start out as 'not found.' A value of -1 in
        # the master file therefore indicates that the galaxy was not fitted or
        # that there was otherwise insufficent data to find the best fit
        # parameters and their errors.
        #######################################################################
        v_max_best = -1
        r_turn_best = -1
        alpha_best = -1
        
#        lum_center_max_best = -1
#        scale_rad_disk_max_best = -1
#        lum_center_min_best = -1
#        scale_rad_disk_min_best = -1
        
        v_max_sigma = -1
        r_turn_sigma = -1
        alpha_sigma = -1
        chi_square_rot = -1
        
#        lum_center_max_sigma = -1
#        scale_rad_disk_max_sigma = -1
#        lum_center_min_sigma = -1
#        scale_rad_disk_min_sigma = -1
#        chi_square_lum_max = -1
#        chi_square_lum_min = -1
        #######################################################################
        
        
        #######################################
        #                                     #
        #     IMPORT DATA FROM DATA FILES     #
        #                                     #
        #######################################
        data_table = ascii.read(rot_file, format='ecsv')
        depro_radii = data_table['deprojected_distance'].value
        rot_vel_data = data_table['rot_vel_avg'].value
        rot_vel_data_err = data_table['rot_vel_avg_error'].value
#        lum_max_data = data_table['avg_luminosity_max'].value
#        lum_min_data = data_table['avg_luminosity_min'].value
        
#        gal_stats_file = data_file[ 0: data_file.find('_rot_curve_data')] \
#                        + '_gal_stat_data.txt'
#        gal_stats_table = ascii.read(gal_stats_file, format='ecsv')
#        lum_center = gal_stats_table['center_luminosity'].value[0]
        #######################################################################
    
    
        #######################################################################
        # General information about the data file in question as well as a plot
        #    of the data before fitting.  
        #######################################################################
#        print( data_file, ":\n\n", data_table, "\n\n")
#        print("DATA TABLE INFORMATION \n",
#              'Columns:', data_table.columns, '\n',
#              'Column Names:', data_table.colnames, '\n',
#              'Meta Data:', data_table.meta, '\n',
#              'Number of Rows:', len( data_table))
#               
#        rot_curve_data_fig = plt.figure(10)
#        plt.plot( depro_radii, rot_vel_max, 'ro')
#        plt.plot( depro_radii, rot_vel_min, 'bo')
#        
#        ax = rot_curve_data_fig.add_subplot(111)
#        plt.tick_params( axis='both', direction='in')
#        ax.yaxis.set_ticks_position('both')
#        ax.xaxis.set_ticks_position('both')
#        
#        plt.ylabel(r'$V_{ROT}$ [$kms^{-1}$]')
#        plt.xlabel(r'$d_{depro}$ [kpc]')
#        plt.title( data_file[data_file.find(ROT_CURVE_MASTER_FOLDER) \
#                             + len(ROT_CURVE_MASTER_FOLDER): \
#                             data_file.find('_rot_curve_data')] \
#                   + " Rotation Curve")
#        plt.show()  
#        
#
#        lum_curve_data_fig = plt.figure(11)
#        plt.plot( depro_radii, lum_max, 'ro')
#        plt.plot( depro_radii, lum_min, 'bo')
#        
#        ax = lum_curve_data_fig.add_subplot(111)
#        plt.tick_params( axis='both', direction='in')
#        ax.yaxis.set_ticks_position('both')
#        ax.xaxis.set_ticks_position('both')
#        
#        plt.ylabel(r'Luminosity [$L_{\odot} / s^2$]')
#        plt.xlabel(r'$d_{depro}$ [kpc]')
#        plt.title( data_file[data_file.find(ROT_CURVE_MASTER_FOLDER) \
#                             + len(ROT_CURVE_MASTER_FOLDER): \
#                             data_file.find('_rot_curve_data')] \
#                   + " Luminosity Curve")
#        plt.show()  
        #######################################################################
    
    
        #######################################################################
        # Create a set of conditions to test for valid data:
        #
        # I.)  The data file should contain at least three data points so as to
        #      fit a rotation curve.
        # II.) The absolute maximum and absolute minimum of each data file
        #      should not be 0.
        #######################################################################
        if len( data_table) >= 3:
            ###################################################################
            # Print the name of the data file in question to keep track of
            #    output.
            ###################################################################
#            print( os.path.split( data_file)[1])
            ###################################################################
        
            ###################################################################
            # Following from 'rot_fit_func,' the following first guesses of the 
            #    parameters 'v_max,' 'r_turn,' and 'alpha' are described as
            #    such:
            #
            # v_max_guess / v_min_guess: 
            #    the absolute maximum and absolute minimum (respectively) of 
            #    the data file in question; first guess of the 'v_max' 
            #    parameter
            #
            # r_turn_max_guess / r_turn_min_guess: 
            #    the radius atwhich 'v_max' and 'v_min' are respectively found;
            #    first guess for 'r_turn' parameter
            #    
            # alpha_guess: imperically-estimated, first guess of the 'alpha'
            #    parameter
            #
            # lum_center_guess: maximum luminosity of the galaxy in question;
            #    this method is also used to find the center of the galaxy in
            #    'rotation_curve_vX_X' and thus is treated as the center 
            #    luminosity
            #
            # scale_rad_guess: for spiral galaxies, the average scale radius
            #    is 3.79 averaging for all morphologies; however, a galaxy's
            #    morphology greatly influences the scale radius
            ###################################################################
            v_max_guess = max( rot_vel_data)
        
            ###################################################################
            # If the initial guesses for the maximum rotational velocity are
            #    not 0, continue with the fitting process.
            ###################################################################
            if v_max_guess != 0:
                r_turn_guess = depro_radii[
                        np.argwhere( rot_vel_data == v_max_guess)][0][0]
            
                alpha_guess = 2
    
                rot_guess = [ v_max_guess, r_turn_guess, alpha_guess]
                ###############################################################
                # Print statement to track the first guesses for the 
                #    'rot_fit_func', and 'lum_fit_func' parameters.
                ###############################################################
#                print("Max Parameter Guess:", rot_guess_max)
#                print("Min Parameter Guess:", rot_guess_min)
#                print("Center Luminosity Guess:", lum_center_guess)
#                print("Scale Radius Guess:", scale_rad_guess)
                ###############################################################
            
                ##################################
                #                                #
                #     FIT DATA VIA FIT FUNCS     #
                #                                #
                ##################################
                ###############################################################
                # Each respective popt holds aN array of the best fit
                #    parameters for the data file in question.
                #
                # Each respective pcov holds the covarience matrix of the
                #    parameters for the data file in question.
                #
                # bounds: imperically-devised limits for  the repective 
                #    'fit_func'
                #
                # max_nfev: the number of times the algorithm will try to fit 
                #    the data
                #
                # loss='cauchy': "Severely weakens outliers influence, but may
                #    cause difficulties in optimization process"
                #    (see link below). 
                #
                # <docs.scipy.org/doc/scipy/reference/generated/
                # scipy.optimize.least_squares.html#scipy.optimize.least_squares>
                #
                # The statements below try to fit the data with 'rot_fit_func' 
                #    and the 'lum_fit_func's as defined above. If 
                #    scipy.optimize.curve_fit hits the max number of times to 
                #    fit the data, the best fit parameters are all set to -999.
                ###############################################################
                
                try:
                    rot_popt, rot_pcov = curve_fit( 
                            rot_fit_func, depro_radii, rot_vel_data,
                            p0 = rot_guess,
                            sigma = rot_vel_data_err,
                            bounds=( ( v_max_guess / 2,
                                      r_turn_guess / 4,
                                      0),
                                     ( v_max_guess * 1.5,
                                      r_turn_guess * 2,
                                      np.inf)),
                            max_nfev=TRY_N, loss='cauchy')
                                                        
                    rot_perr = np.sqrt( np.diag( rot_pcov))
                    
                    v_max_best = rot_popt[0]
                    r_turn_best = rot_popt[1]
                    alpha_best = rot_popt[2]
                    
                    v_max_sigma = rot_perr[0]
                    r_turn_sigma = rot_perr[1]
                    alpha_sigma = rot_perr[2]
                    
                    i = 0
                    chi_square_rot = 0
                    for radius, velocity, vel_err in \
                      zip( depro_radii, rot_vel_data, rot_vel_data_err):
                        observed = velocity / (u.km/u.s)
                        expected = rot_fit_func( 
                               radius / (u.kpc),  
                               v_max_best, 
                               r_turn_best, 
                               alpha_best)
                        error = vel_err / (u.km/u.s)
                        chi_square_rot += (observed - expected)**2 / error**2
                        i += 1
            
                except RuntimeError:
                    ###########################################################
                    # If the program experiences a RuntimeError, it is assumed
                    #    that scipy.optimize.curve_fit could not find the best 
                    #    fit parameters. The data given in the rotation curve
                    #    file was otherwise satisfactory. Values of -999 are
                    #    reported in instances where this RuntimeError occurs.
                    ###########################################################
                    v_max_best = -999
                    r_turn_best = -999
                    alpha_best = -999

                    v_max_sigma = -999
                    r_turn_sigma = -999
                    alpha_sigma = -999
                    chi_square_rot = -999
                
                
#                try:
#                    scale_rad_disk_max_guess = depro_radii[
#                            np.argwhere( lum_max <= lum_max[0] / 2)][0][0]
#                
#                    scale_rad_disk_min_guess = depro_radii[
#                            np.argwhere( lum_min <= lum_min[0] / 2)][0][0]
#                except IndexError:
#                    scale_rad_disk_max_guess = depro_radii[ 
#                            int( len(depro_radii) / 3)]
#                    scale_rad_disk_min_guess = scale_rad_disk_max_guess
#                
#                lum_guess_max = [ lum_center,
#                                  scale_rad_disk_max_guess]
#                lum_guess_min = [ lum_center,
#                                  scale_rad_disk_min_guess]
                
#                print(lum_guess_max)
#                print(lum_guess_min)
                
#                try:
                    ###########################################################
                    # If v_max_best = -999, that means that the galaxy in
                    #    question's rotation curves could not be fit. The other
                    #    parameters are not tested in the if condition 
                    #    because if v_max_best = -999, then all the others are
                    #    also -999. In instances such as these, -9 is assigned 
                    #   to the luminosity best fit parameters as well as their 
                    #   errors.
                    ###########################################################
#                    if v_max_best == -999:
#                        lum_center_max_best = -9
#                        scale_rad_disk_max_best = -9
#                        lum_center_min_best = -9
#                        scale_rad_disk_min_best = -9
                    
#                        lum_center_max_sigma = -9
#                        scale_rad_disk_max_sigma = -9
#                        lum_center_min_sigma = -9
#                        scale_rad_disk_min_sigma = -9
#                        
#                        chi_square_lum_max = -9
#                        chi_square_lum_min = -9
                        
#                    else:
#                        print("Radii Data:", depro_radii)
#                        print("lum_max_data:", lum_max_data)
#                        print("lum_min_data:", lum_min_data)
#                        print('\n')
#                        
#                        lum_popt_max, lum_pcov_max = curve_fit( lum_fit_func_disk,
#                                                       depro_radii, lum_max,
#                                                       p0 = lum_guess_max,
#                                                       bounds = (
#                                                          (0, 0),
#                                                          (2.25 * lum_center, 
#                                                          1.5*max(depro_radii))),
#                                                       max_nfev = TRY_N,
#                                                       loss='cauchy')
#                                           
#                        lum_popt_min, lum_pcov_min = curve_fit( lum_fit_func_disk, 
#                                                       depro_radii, lum_min, 
#                                                       p0 = lum_guess_min,
#                                                       bounds = (
#                                                          (0, 0),
#                                                          (2.25 * lum_center, 
#                                                          1.5*max(depro_radii))),
#                                                       max_nfev = TRY_N,
#                                                       loss='cauchy')
#                                                        
#                        lum_perr_max = np.sqrt( np.diag( lum_pcov_max))
#                        lum_perr_min = np.sqrt( np.diag( lum_pcov_min))
                    
#                    
#                        lum_center_max_best = lum_popt_max[0]
#                        scale_rad_disk_max_best = lum_popt_max[1]
#                        lum_center_min_best = lum_popt_min[0]
#                        scale_rad_disk_min_best = lum_popt_min[1]
#                    
#                        lum_center_max_sigma = lum_perr_max[0]                              
#                        scale_rad_disk_max_sigma = lum_perr_max[1]
#                        lum_center_min_sigma = lum_perr_min[0]
#                        scale_rad_disk_min_sigma = lum_perr_min[1]
#                        
#                except RuntimeError:
                    ###########################################################
                    # If the program experiences a RuntimeError, it is assumed
                    #    that scipy.optimize.curve_fit could not find the best 
                    #    fit parameters. The data given in the luminosity curve
                    #    columns was otherwise satisfactory. Values of -999 are
                    #    reported in instances where this RuntimeError occurs.
                    ###########################################################
#                    lum_center_max_best = -999
#                    scale_rad_disk_max_best = -999
#                    lum_center_min_best = -999
#                    scale_rad_disk_min_best = -999
                    
#                    lum_center_max_sigma = -999
#                    scale_rad_disk_max_sigma = -999
#                    lum_center_min_sigma = -999
#                    scale_rad_disk_min_sigma = -999
#                    
#                    chi_square_lum_max = -999
#                    chi_square_lum_min = -999
#                    
#                except ValueError:
#                    print("x0 is PROBABLY infeasible.")
#                    infeasible_x0.append( data_file[data_file.find(
#                                                    ROT_CURVE_MASTER_FOLDER) \
#                                            + len(ROT_CURVE_MASTER_FOLDER): \
#                                            data_file.find('_rot_curve_data')])
                    
                                               
                ###############################################################
                # Print statement to track the best fit parameters for the data
                #    file in question as well as code to plot the data file in
                #    question along with the line of best fit.
                ###############################################################
                print("Rot Curve Best Param:", rot_popt)
#                print("Lum Curve Max Best Param:", lum_popt_max)
#                print("Lum Curve Min Best Param:", lum_popt_min)
                print('\n')
                
                ###############################################################
                # Calculate the chi^2 values for each fitted luminosity curve.
                ###############################################################                                    
#                i = 0
#                chi_square_lum_max = 0
#                for data_point in data_table['deprojected_distance']:
#                    observed = data_table['avg_luminosity_max'][i] / (u.L_sun)
#                    expected = lum_fit_func_disk( 
#                               data_table['deprojected_distance'][i] / (u.kpc),
#                               lum_popt_max[0], 
#                               lum_popt_max[1])
#                    chi_square_lum_max += (observed - expected)**2 / expected
#                    i += 1
#                    
#                    
#                i = 0
#                chi_square_lum_min = 0
#                for data_point in data_table['deprojected_distance']:
#                    observed = data_table['avg_luminosity_min'][i] / (u.L_sun)
#                    expected = lum_fit_func_disk( 
#                               data_table['deprojected_distance'][i] / (u.kpc),
#                               lum_popt_min[0], 
#                               lum_popt_min[1])
#                    chi_square_lum_min += (observed - expected)**2 / expected
#                    i += 1
                    
                ###############################################################
                # If a chi_square value is calculated to be infinity, set the 
                #    chi_square to -50 so that it does not trigger issues in
                #    plotting a histogram of the values.
                ###############################################################
                if chi_square_rot == float('inf'):
                    chi_square_rot_max = -50
#                if chi_square_lum_max == float('inf'):
#                    chi_square_lum_max = -50
#                if chi_square_lum_min == float('inf'):
#                    chi_square_lum_min = -50
                ###############################################################
                    
                print("chi_square_rot:", chi_square_rot)
#                print("chi_square_lum_max:", chi_square_lum_max)
#                print("chi_square_lum_min:", chi_square_lum_min)
                    
                ###############################################################
                # Plot the luminosity and rotational velocity data gathered
                #    along with the associated fit functions. The option to 
                #    save the images to a file location is also given.
                ###############################################################
            
                #######################
                # Rotation Curve Plot #
                #######################
                fitted_rot_curve_fig = plt.figure(20)
                plt.plot( depro_radii,
                         rot_vel_data, 'go')
                plt.plot( np.linspace( 0, depro_radii[-1], 10000),
                         rot_fit_func(np.linspace( 0, depro_radii[-1], 10000),
                                  v_max_best, 
                                  r_turn_best, 
                                  alpha_best), 
                                  'g--')
                
                ax = fitted_rot_curve_fig.add_subplot(111)
                plt.tick_params( axis='both', direction='in')
                ax.yaxis.set_ticks_position('both')
                ax.xaxis.set_ticks_position('both')
                plt.ylabel(r'$V_{ROT}$ [$kms^{-1}$]')
                plt.xlabel(r'$d_{depro}$ [kpc]')              
                plt.title( data_file[data_file.find(ROT_CURVE_MASTER_FOLDER) \
                             + len(ROT_CURVE_MASTER_FOLDER): \
                             data_file.find('_rot_curve_data')] + \
                             ' Fitted Rotation Curve')
                
                ax.text(0.07, 0.97, "Chi^2: " + str( chi_square_rot),
                verticalalignment='top', horizontalalignment='left',
                transform=ax.transAxes,
                color='green', fontsize=8)
                
                rot_image_directory = LOCAL_PATH + \
                             '\\Images\\Fitted_Rotation_Curves\\'
                plt.savefig( rot_image_directory + '_Fitted_Rotation_Curve.png')
                plt.show() 
                
                #########################
                # Luminosity Curve Plot #
                #########################
#                fitted_lum_curve_fig = plt.figure(20)
#                plt.plot( data_table['deprojected_distance'],
#                         data_table['avg_luminosity_max'], 'ro')
#                plt.plot( data_table['deprojected_distance'],
#                         data_table['avg_luminosity_min'], 'bo')
#                plt.plot( np.linspace( 0, depro_radii[-1], 10000),
#                         lum_fit_func_disk(np.linspace( 0, depro_radii[-1], 10000),
#                                  lum_popt_max[0], 
#                                  lum_popt_max[1]), 
#                                  'r--')
#                plt.plot( np.linspace( 0, depro_radii[-1], 10000),
#                         lum_fit_func_disk(np.linspace( 0, depro_radii[-1], 10000),
#                                  lum_popt_min[0],
#                                  lum_popt_min[1]), 
#                                  'b-.')
#                
#                ax = fitted_lum_curve_fig.add_subplot(111)
#                plt.tick_params( axis='both', direction='in')
#                ax.yaxis.set_ticks_position('both')
#                ax.xaxis.set_ticks_position('both')
#                plt.ylabel(r'Luminosity [$L_{\odot}$]') 
#                plt.xlabel(r'$d_{depro}$ [kpc]')
#                plt.title( data_file[data_file.find(ROT_CURVE_MASTER_FOLDER) \
#                             + len(ROT_CURVE_MASTER_FOLDER): \
#                             data_file.find('_rot_curve_data')] + \
#                             ' Fitted Luminosity Curve')
#                
#                ax.text(0.96, 0.97, "Chi^2 Max: " + str( chi_square_lum_max),
#                verticalalignment='top', horizontalalignment='right',
#                transform=ax.transAxes,
#                color='red', fontsize=8)
                
                #f'The value of pi is approximately {math.pi:.3f}.'
                
#                ax.text(0.96, 0.92, f"Chi^2 Min: " + str( chi_square_lum_min),
#                verticalalignment='top', horizontalalignment='right',
#                transform=ax.transAxes,
#                color='blue', fontsize=8)
                
#                lum_image_directory = LOCAL_PATH + \
#                             '\\Images\\Fitted_Luminosity_Curves\\'
#                
#                if not os.path.exists( lum_image_directory):
#                  os.makedirs( lum_image_directory)
#                plt.savefig( lum_image_directory + '_Fitted_Luminosity_Curve.png')
#                plt.show() 
            
#                print("Index in 'rot_curve_files':", idx_files)
                print("-----------------------------------------------------")   
                ###############################################################
                
            ###################################################################
            # If either the absolute maximum or the absolute minimum of the 
            #    data file in question is zero, the best fit parameters and 
            #    their errors are set to -100.
            ###################################################################
            elif v_max_guess == 0 or v_min_guess == 0:
                v_max_best = -100
                r_turn_max_best = -100
                alpha_max_best = -100
                v_min_best = -100
                r_turn_min_best = -100
                alpha_min_best = -100
        
#               lum_center_max_best = -100
#               scale_rad_disk_max_best = -100
#               lum_center_min_best = -100
#               scale_rad_disk_min_best = -100
        
                v_max_sigma = -100
                r_turn_max_sigma = -100
                alpha_max_sigma = -100
                v_min_sigma = -100
                r_turn_min_sigma = -100
                alpha_min_sigma = -100
                chi_square_rot_max = -100
                chi_square_rot_min = -100
        
#               lum_center_max_sigma = -100
#               scale_rad_disk_max_sigma = -100
#               lum_center_min_sigma = -100
#               scale_rad_disk_min_sigma = -100
#               chi_square_lum_max = -100
#               chi_square_lum_min = -100
            
        #######################################################################
        # If the data file in question has less than three data points, the
        #    best fit parameters along with their errors are left as
        #    initialized (-1). 
        #######################################################################
        elif len( data_table) < 3:
            pass        
        
        v_max_best_master.append( v_max_best)
        r_turn_max_best_master.append( r_turn_max_best)
        alpha_max_best_master.append( alpha_max_best)
        v_min_best_master.append( v_min_best)
        r_turn_min_best_master.append( r_turn_min_best)
        alpha_min_best_master.append( alpha_min_best)  
                
#        lum_center_max_best_master.append( lum_center_max_best)
#        scale_rad_disk_max_best_master.append( scale_rad_disk_max_best)
#        lum_center_min_best_master.append( lum_center_min_best)
#        scale_rad_disk_min_best_master.append( scale_rad_disk_min_best)
        
        v_max_sigma_master.append( v_max_sigma)
        r_turn_max_sigma_master.append( r_turn_max_sigma)
        alpha_max_sigma_master.append( alpha_max_sigma)
        v_min_sigma_master.append( v_min_sigma)
        r_turn_min_sigma_master.append( r_turn_min_sigma)
        alpha_min_sigma_master.append( alpha_min_sigma)
        chi_square_rot_max_master.append( chi_square_rot_max)
        chi_square_rot_min_master.append( chi_square_rot_min)        
        
#        lum_center_max_sigma_master.append( lum_center_max_sigma)
#        scale_rad_disk_max_sigma_master.append( scale_rad_disk_max_sigma)
#        lum_center_min_sigma_master.append( lum_center_min_sigma)
#        scale_rad_disk_min_sigma_master.append( scale_rad_disk_min_sigma)
#        chi_square_lum_max_master.append( chi_square_lum_max)
#        chi_square_lum_min_master.append( chi_square_lum_min)
        
        
        ####################################################################### 

      
        #######################################################################
        # Print statement to keep track of which files have been fitted.
        #
        # print( data_file, "PROCESSED")
        #######################################################################
    
    v_max_best_col = Column( v_max_best_master)
    r_turn_max_best_col = Column( r_turn_max_best_master)
    alpha_max_best_col = Column( alpha_max_best_master)
    v_min_best_col = Column( v_min_best_master)
    r_turn_min_best_col = Column( r_turn_min_best_master)
    alpha_min_best_col = Column( alpha_min_best_master)
    
#    lum_center_max_best_col = Column( lum_center_max_best_master)
#    scale_rad_disk_max_best_col = Column( scale_rad_disk_max_best_master)
#    lum_center_min_best_col = Column( lum_center_min_best_master)
#    scale_rad_disk_min_best_col = Column( scale_rad_disk_min_best_master)
    
    v_max_sigma_col = Column( v_max_sigma_master)
    r_turn_max_sigma_col = Column( r_turn_max_sigma_master)
    alpha_max_sigma_col = Column( alpha_max_sigma_master)
    v_min_sigma_col = Column( v_min_sigma_master)
    r_turn_min_sigma_col = Column( r_turn_min_sigma_master)
    alpha_min_sigma_col = Column( alpha_min_sigma_master)
    chi_square_rot_max_col = Column( chi_square_rot_max_master)
    chi_square_rot_min_col = Column( chi_square_rot_min_master)
    
    
#    lum_center_max_sigma_col = Column( lum_center_max_sigma_master)
#    scale_rad_disk_max_sigma_col = Column( scale_rad_disk_max_sigma_master)
#    lum_center_min_sigma_col = Column( lum_center_min_sigma_master)
#    scale_rad_disk_min_sigma_col = Column( scale_rad_disk_min_sigma_master)
#    chi_square_lum_max_col = Column( chi_square_lum_max_master)
#    chi_square_lum_min_col = Column( chi_square_lum_min_master)
        
    best_fit_param_table = QTable( [v_max_best_col * (u.m / u.s),
                                    v_max_sigma_col * (u.m / u.s),
                                    r_turn_max_best_col * u.kpc,
                                    r_turn_max_sigma_col * u.kpc,
                                    alpha_max_best_col,
                                    alpha_max_sigma_col,
                                    v_min_best_col * (u.m / u.s),
                                    v_min_sigma_col * (u.m / u.s),
                                    r_turn_min_best_col * u.kpc,
                                    r_turn_min_sigma_col * u.kpc,
                                    alpha_min_best_col,
                                    alpha_min_sigma_col,
                                    chi_square_rot_max_col,
                                    chi_square_rot_min_col],
#                                    lum_center_max_best_col * u.L_sun,
#                                    lum_center_max_sigma_col * u.L_sun,
#                                    scale_rad_disk_max_best_col * u.kpc,
#                                    scale_rad_disk_max_sigma_col * u.kpc,
#                                    lum_center_min_best_col * u.L_sun,
#                                    lum_center_min_sigma_col * u.L_sun,
#                                    scale_rad_disk_min_best_col * u.kpc,
#                                    scale_rad_disk_min_sigma_col * u.kpc,
#                                    chi_square_lum_max_col,
#                                    chi_square_lum_min_col],
                           names = ['max_vel_best',
                                    'max_vel_err',
                                    'turn_rad_max_best',
                                    'turn_rad_max_err',
                                    'alpha_max_best',
                                    'alpha_max_err',
                                    'min_vel_best',
                                    'min_vel_err',
                                    'turn_rad_min_best',
                                    'turn_rad_min_err',
                                    'alpha_min_best',
                                    'alpha_min_err',
                                    'chi_square_rot_max',
                                    'chi_square_rot_min'])
#                                    'lum_center_max_best',
#                                    'lum_center_max_err',
#                                    'scale_rad_disk_max_best',
#                                    'scale_rad_disk_max_err',
#                                    'lum_center_min_best',
#                                    'lum_center_min_err',
#                                    'scale_rad_disk_min_best',
#                                    'scale_rad_disk_min_err',
#                                    'chi_square_lum_max',
#                                    'chi_square_lum_min'])  
    
    print("Infeasible x0:", infeasible_x0)
    print("Length of Infeasible_x0:", len( infeasible_x0))
    
    return best_fit_param_table

def extract_matched_data( MASTER_FILE_NAME, CROSS_REF_FILE_NAME, LOCAL_PATH):
    """Match each galaxy in the master file to Prof. Kelly Douglass' file
    (see link below) and extract the vflag parameter {0, 1, 2} that tells 
    if the galaxy in question does not lie in a void {0}, does lie in a void
    {1} or is an edge-on galaxy and therefore impossible to determine {2}. Also
    extract the 'Mstar_NSA' parameter that gives information about a galaxy's
    stellar mass.
    
    <http://www.pas.rochester.edu/~kdouglass/Research/
    kias1033_5_P-MJD-F_MPAJHU_Zdust_stellarMass_BPT_SFR_NSA_correctVflag.txt>
    
    @param:
        MASTER_FILE_NAME:
            string representation of the master file containing the best fit
            parameters, their errors, and identifying information about each
            galaxy
            
        CROSS_REF_FILE_NAME:
            string representation of Prof. Kelly Douglass' file used to cross
            reference for vflag.
            
        LOCAL_PATH:
            string representation of the directory of the main script
            
    @return: 
        vflag_master:
            master list containing each galaxy's 'vflag' parameter
            
        mstar_NSA_master:
            master list containing each galaxy's 'Mstar_NSA' parameter
    """
    master_table = ascii.read( LOCAL_PATH + MASTER_FILE_NAME, 
                                   format='ecsv', 
                                   include_names = ('NSA_plate',
                                                    'NSA_fiberID',
                                                    'NSA_MJD'))
    ref_table = ascii.read( LOCAL_PATH + CROSS_REF_FILE_NAME,
                           include_names = ('plate',
                                            'MJD',
                                            'fiberID',
                                            'vflag',
                                            'Mstar_NSA'))
    
    vflag_master = np.full( len( master_table), -1)
    mstar_NSA_master = np.full( len( master_table), -1, dtype=np.int64)    
    
    for i in range( len( master_table)):        
        target_plate = master_table['NSA_plate'][i]
        target_mjd = master_table['NSA_MJD'][i]
        target_fiberID = master_table['NSA_fiberID'][i]
        
        #######################################################################
        # The code below first matches via the 'target_plate' value. Of those
        #    matches, the next line matches via 'target_MJD.' Finally, of those
        #    galaxies in 'vflag_ref_table' that match both the galaxy in
        #    question's plate and MJD, the remaining line matches via
        #    'target_fiberID.'
        #
        # NOTE: At the conclusion of these three matching statements, only
        #       one galaxy match should be found within 'ref_table.'
        #######################################################################
        # MATCH PLATE
        plate_matches = ref_table['plate'] == target_plate
        # MATCH MJD
        mjd_matches = ref_table['MJD'] == target_mjd
        # MATCH FIBERID
        fiberID_matches = ref_table['fiberID'] == target_fiberID
            
        galaxy_matches = np.logical_and.reduce(( plate_matches, mjd_matches,
                                                fiberID_matches))
        
        #######################################################################
        # This statement pulls out the 'vflag' parameter from Prof. Kelly
        #    Douglass' file.
        #
        # NOTE: There are four "[0]" trailing the matched galaxy in 
        #       'vflag_ref_table.' It is unclear why this must be done, but
        #       this code should return the 'vflag' parameter. It is 
        #       theorized that when matching, additional tables are hashed 
        #       together; thus to counteract this, four trailing "[0]" must 
        #       be added to access 'vflag.'
        #######################################################################
        if len( ref_table[ galaxy_matches]) == 1 and \
        np.isfinite( ref_table['Mstar_NSA'][galaxy_matches]):
#            print( ref_table[galaxy_matches]['Mstar_NSA'][0])
#            print( ref_table[galaxy_matches]['vflag'][0])
            vflag_master[i] = ref_table[galaxy_matches]['vflag'][0]
            mstar_NSA_master[i] = ref_table[galaxy_matches]['Mstar_NSA'][0] \
                                    * u.M_sun
    
    return vflag_master, mstar_NSA_master

def write_best_params( best_fit_param_table, gal_stats_files, LOCAL_PATH, 
                      MASTER_FILE_NAME, ROT_CURVE_MASTER_FOLDER):
    """Writes the list of galaxies along with the respective best fit
    parameters and galaxy statistics to a text file indicated in the 
    'MASTER_FILE_NAME' variable.
    
    @param:
        gal_stats_files:
            string list of galaxies for which general statistical data exists
            
        best_fit_param_table:
            astropy QTable that contains:
                i.) MaNGA plate and fiberID for identification
               ii.) the best fit parameters for the max and min rotation
                       curves
              iii.) the best fit patameters for the max and min luminosity
                       curves
        
        LOCAL_PATH:
            string representation of the directory path of this file
            
        MASTER_FILE_NAME:
            string representation of the name of the file which 
            'best_fit_param_table' will be written to
            
        ROT_CURVE_MASTER_FOLDER:
            string representation of the path of the folder containing all of 
            the galaxy data for all of the galaxies in the MaNGA survey
            
    @return: function returns the boolean True upon completion
    """
    master_table = ascii.read( LOCAL_PATH + MASTER_FILE_NAME, format='ecsv')
    
    master_table.add_column( best_fit_param_table['max_vel_best'])
    master_table.add_column( best_fit_param_table['max_vel_err'])
    master_table.add_column( best_fit_param_table['turn_rad_max_best'])
    master_table.add_column( best_fit_param_table['turn_rad_max_err'])
    master_table.add_column( best_fit_param_table['alpha_max_best'])
    master_table.add_column( best_fit_param_table['alpha_max_err'])
    master_table.add_column( best_fit_param_table['min_vel_best'])
    master_table.add_column( best_fit_param_table['min_vel_err'])
    master_table.add_column( best_fit_param_table['turn_rad_min_best'])
    master_table.add_column( best_fit_param_table['turn_rad_min_err'])
    master_table.add_column( best_fit_param_table['alpha_min_best'])
    master_table.add_column( best_fit_param_table['alpha_min_err'])
    master_table.add_column( best_fit_param_table['chi_square_rot_max'])
    master_table.add_column( best_fit_param_table['chi_square_rot_min'])
#    master_table.add_column( best_fit_param_table['lum_center_max_best'])
#    master_table.add_column( best_fit_param_table['lum_center_max_err'])
#    master_table.add_column( best_fit_param_table['scale_rad_disk_max_best'])
#    master_table.add_column( best_fit_param_table['scale_rad_disk_max_err'])
#    master_table.add_column( best_fit_param_table['lum_center_min_best'])
#    master_table.add_column( best_fit_param_table['lum_center_min_err'])
#    master_table.add_column( best_fit_param_table['scale_rad_disk_min_best'])
#    master_table.add_column( best_fit_param_table['scale_rad_disk_min_err'])   
    
    lum_unprocessed_master = []
    lum_unprocessed_err_master = []
    mass_unprocessed_master = []
    mass_unprocessed_err_master = []
    
    for data_file in gal_stats_files:
        
        gal_stats_table = ascii.read(data_file, format='ecsv')
        lum_unprocessed = gal_stats_table['luminosity_unprocessed'].value[0]
        lum_unprocessed_err = gal_stats_table[
                'luminosity_unprocessed_error'].value[0]
        mass_unprocessed = gal_stats_table['mass_unprocessed'].value[0]
        mass_unprocessed_err = gal_stats_table['mass_unprocessed_error'].value[0]
        
        lum_unprocessed_master.append( lum_unprocessed)
        lum_unprocessed_err_master.append( lum_unprocessed_err)
        mass_unprocessed_master.append( mass_unprocessed)
        mass_unprocessed_err_master.append( mass_unprocessed_err)
        
    master_table.add_column( Column( lum_unprocessed_master), 
                            name='lum_unprocessed')
    master_table.add_column( Column( lum_unprocessed_err_master), 
                            name='lum_unprocessed_error')
    master_table.add_column( Column( mass_unprocessed_master), 
                            name='mass_unprocessed')
    master_table.add_column( Column( mass_unprocessed_err_master), 
                            name='mass_unprocessed_error')
    
    
    
    ascii.write(master_table,
                LOCAL_PATH + MASTER_FILE_NAME,
                format = 'ecsv',
                overwrite = True)
    
    return True

def write_matched_data( vflag_list, mstar_NSA_list, LOCAL_PATH, 
                       MASTER_FILE_NAME):
    """Writes the vflag parameter to the master file for each corresponding 
    galaxy. 
    
    @param:
        vflag_list:
            list containing all of the 'vflag' parameters for each galaxy
            
        mstar_NSA_list:
            list containing all the 'mstar_NSA' parameters for each galaxy
            
        LOCAL_PATH:
            string representation of the directory of the main script file
            
        MASTER_FILE_NAME:
            string representation of the name of the file which 'vflag_list'
            will be written to
    """
    master_table = ascii.read( LOCAL_PATH + MASTER_FILE_NAME, format='ecsv')
    
    master_table.add_column( Column( vflag_list), name='vflag')
    master_table.add_column( Column( mstar_NSA_list), name='Mstar_NSA')
    
    ascii.write(master_table,
                LOCAL_PATH + MASTER_FILE_NAME,
                format = 'ecsv',
                overwrite = True)
    
    return True

def analyze_rot_curve_discrep( rot_curve_files, gal_stat_files, 
                      LOCAL_PATH, MASTER_FILE_NAME, ROT_CURVE_MASTER_FOLDER):
    """Analyze the discrepancies between minimum and maximum rotation curves. 
    The difference between the rotation curves and average of the rotation 
    curves are both averaged themselves by the number of data points in the 
    curve to report a single float number for the difference and average for 
    each galaxy. 
    
    NOTE: No correlation was found between if the galaxy resides within a wall 
    vs. a void.
    
    @param:
        rot_curve_files:
            a string list containing all of the data files within the 
            'rotation_curve_vX_X' output folder
            
        gal_stats_files:
            string list of galaxies for which general statistical data exists
            
        LOCAL_PATH:
            string representation of the directory of the main script file
            
        MASTER_FILE_NAME:
            string representation of the name of the file which 'vflag_list'
            will be written to
            
        ROT_CURVE_MASTER_FOLDER:
            string representation of the path of the folder containing all of 
            the galaxy data for all of the galaxies in the MaNGA survey
    """  
    BINS = np.linspace( -1000, 1000, 50)
    
    rot_vel_diff_wall = []
    rot_vel_diff_void = []
    rot_vel_avg_wall = []
    rot_vel_avg_void = []
    
    master_file = ascii.read(LOCAL_PATH + MASTER_FILE_NAME, format='ecsv')
    vflag_list = master_file['vflag']
    
    i = 0
    for data_file in rot_curve_files:
        data_table = ascii.read(data_file, format='ecsv')
        depro_radii = data_table['deprojected_distance'].value
        rot_vel_max = data_table['max_velocity'].value
        rot_vel_min = data_table['min_velocity'].value
        
        rot_vel_diff_curve = abs( rot_vel_max - rot_vel_min)
        rot_vel_avg_curve = (rot_vel_max + rot_vel_min) / 2
        
        rot_vel_diff_tot = 0
        rot_vel_avg_tot = 0
        for diff, avg in zip( rot_vel_diff_curve, rot_vel_avg_curve):
            rot_vel_diff_tot += diff
            rot_vel_avg_tot += avg
            
        rot_vel_diff = rot_vel_diff_tot / len( depro_radii)
        rot_vel_avg = rot_vel_avg_tot / len( depro_radii)
        
        if vflag_list[i] == 0:
            rot_vel_diff_wall.append( rot_vel_diff)
            rot_vel_avg_wall.append( rot_vel_avg)
            
        if vflag_list[i] == 1:
            rot_vel_diff_void.append( rot_vel_diff)
            rot_vel_avg_void.append( rot_vel_avg)

    hist_diff_fig = plt.figure()
    plt.title("Rotation Curve Difference Histogram")
    plt.hist( rot_vel_diff_wall, BINS, color='black', density=True)
    plt.hist( rot_vel_diff_void, BINS, color='red', density=True, alpha=0.5)

    ax = hist_diff_fig.add_subplot(111)
    plt.tick_params( axis='both', direction='in')
    ax.yaxis.set_ticks_position('both')
    ax.xaxis.set_ticks_position('both')                 
    plt.ylabel(r'$Fraction_{galaxy}$')
    plt.xlabel(r'$v_{diff}$ [km/s]')


    hist_avg_fig = plt.figure()
    plt.title("Rotation Curve Average Histogram")
    plt.hist( rot_vel_avg_wall, BINS, color='black', density=True)
    plt.hist( rot_vel_avg_void, BINS, color='red', density=True, alpha=0.5)

    ax = hist_avg_fig.add_subplot(111)
    plt.tick_params( axis='both', direction='in')
    ax.yaxis.set_ticks_position('both')
    ax.xaxis.set_ticks_position('both')                 
    plt.ylabel(r'$Fraction_{galaxy}$')
    plt.xlabel(r'$v_{avg}$ [km/s]')
        
    return None

def analyze_chi_square( LOCAL_PATH, MASTER_FILE_NAME):
    """Histogram the chi square values for the fit function parameters obtained
    in fitting the curves.
    
    Chi square values are separated into different figures by min/max rotation
    curve. Within each histogram each chi square distribution is also separated
    by wall versus void. The total distribution is also plotted for comparison.
    
    @param:
        MASTER_FILE_NAME:
            string representation of the name of the file which 'vflag_list'
            and the chi square values will be pulled from
    """
    BINS = np.linspace( -1000, 1000, 50)
    
    master_file = ascii.read(LOCAL_PATH + MASTER_FILE_NAME, format='ecsv')
    vflag_list = master_file['vflag']
    
    chi_square_rot_max_master = master_file['chi_square_rot_max']
    chi_square_rot_max_wall = []
    chi_square_rot_max_void = []
    
    chi_square_rot_min_master = master_file['chi_square_rot_min']    
    chi_square_rot_min_wall = []
    chi_square_rot_min_void = []
    
    for vflag, chi_square_max \
      in zip( vflag_list, chi_square_rot_max_master):
        if vflag == 0:
            chi_square_rot_max_wall.append( chi_square_max)
            
        if vflag == 1:
            chi_square_rot_max_void.append( chi_square_max)
            
    for vflag, chi_square_min \
      in zip( vflag_list, chi_square_rot_min_master):
        if vflag == 0:
            chi_square_rot_min_wall.append( chi_square_min)
            
        if vflag == 1:
            chi_square_rot_min_void.append( chi_square_min)
            
            
    chi_square_rot_max_fig = plt.figure()
    plt.title("Chi Square (MAX Curves) Histogram")
    plt.hist( chi_square_rot_max_master, BINS, color='green', density=True)
    plt.hist( chi_square_rot_max_wall, 
             BINS, color='black', density=True, alpha=0.5)
    plt.hist( chi_square_rot_max_void, 
             BINS, color='red', density=True, alpha=0.3)

    ax = chi_square_rot_max_fig.add_subplot(111)
    plt.tick_params( axis='both', direction='in')
    ax.yaxis.set_ticks_position('both')
    ax.xaxis.set_ticks_position('both')                 
    plt.ylabel(r'$Fraction_{galaxy}$')
    plt.xlabel('Chi Square (Goodness of Fit)')
    
    
    chi_square_rot_min_fig = plt.figure()
    plt.title("Chi Square (MIN Curves) Histogram")
    plt.hist( chi_square_rot_min_master, BINS, color='blue', density=True)
    plt.hist( chi_square_rot_min_wall, 
             BINS, color='black', density=True, alpha=0.5)
    plt.hist( chi_square_rot_min_void, 
             BINS, color='red', density=True, alpha=0.3)

    ax = chi_square_rot_min_fig.add_subplot(111)
    plt.tick_params( axis='both', direction='in')
    ax.yaxis.set_ticks_position('both')
    ax.xaxis.set_ticks_position('both')                 
    plt.ylabel(r'$Fraction_{galaxy}$')
    plt.xlabel('Chi Square (Goodness of Fit)')