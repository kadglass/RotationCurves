#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Created on Wed Jun 06 2018
@author: Jacob A. Smith
@version: 1.0

Analyzes mainly face-on galaxies in an attempt to compute the rotation
curve (rotational velocity as a function of radius).

To download data: http://www.sdss.org/dr14/manga/manga-data/data-access/
"""
########################################
# Optional import statement to import  #
#    matplotlib.pyplot if needed for   #
#    graphing diagnostics.             #
########################################
# import matplotlib.pyplot as plt

import os.path

import math
import numpy as np
import warnings
warnings.simplefilter('ignore', np.RankWarning)

from astropy.io import fits, ascii
from astropy.coordinates import SkyCoord
from astropy.table import QTable, Column
import astropy.units as u
import astropy.constants as const

######################
# Declare constants. #
######################

H_0 = 100       # Hubble's Constant in units of km /s /Mpc
    
MANGA_FIBER_DIAMETER = 9.69627362219072e-06   # angular fiber diameter
                                              #   (2") in radians

def extract_data( file_name, start):
    """Open the MaNGA .fits file and extract data.
    
    @param:
        file_name:
            a string representation of the galaxy in question in the 
            following format: manga-[PLATE]-[IFUID].Pipe3D.cube.fits.gz
            
        start:
            the start time of the main script to test for performance
    
    @return:
        Ha_vel:
            an n-D numpy array containing the H-alpha velocity field data
        
        v_band[0]:
            an n-D numpy array containing the visual-band flux data
        
        org_hdr:
            original header of the .fits file that contains the galaxy's
                 RA and DEC in list-like format
    """
    main_file = fits.open( file_name)
    
    flux_elines = main_file[3].data
    Ha_vel = flux_elines[102]
    
    v_band = main_file[1].data
    org_hdr = main_file[0].header
    
    main_file.close()
    
    return Ha_vel, v_band[0], org_hdr
    

def match( gal_ra, gal_dec, cat_coords, file_name, start):
    """Match the galaxy in question to the NSA Catalog.
    
    @param:
        gal_ra:
            the galaxy in question's righthand ascension
        
        gal_dec:
            the galaxy in question's declination
        
        cat_coords:
            SkyCoord master list containing all of the righthand ascension
            and declination for the galaxies contained in the NSA
            catalog
            ATTN: cat_coords must be a list of SkyCoord objects
            
        file_name:
            a string representation of the galaxy in question in the 
            following format: manga-[PLATE]-[IFUID].Pipe3D.cube.fits.gz
            
        start:
            the start time of the main script to test for performance

    @return:
        idx:
            the NSA catalog integer index of the galaxy in question
    """
    gal_coord = SkyCoord( ra = gal_ra * u.degree,
                         dec = gal_dec * u.degree)

    idx = gal_coord.match_to_catalog_sky( cat_coords)[0]

    return idx

    #############################################################
    # DIAGNOSTICS:                                              #
    #-----------------------------------------------------------#
    # print(gal_coord)                                          #
    # print("NSA index of galaxy:", idx)                        #
    #############################################################


def rot_curve( Ha_vel, v_band, axes_ratio, phi_EofN_deg, zdist, file_name,
              start):
    """Calculates the rotation curve, deprojected distance as a funciton of
    deprojected velocity, of the galaxy in question.
    
    @param:
        Ha_vel:
            an n-D numpy array containing the H-alpha velocity field data
        
        v_band:
            an n-D numpy array containing the visual band flux data
        
        axes_ratio:
            the float ratio of the galaxy's minor axis of the major
            axis as obtained via a sersic fit of the galaxy
                    
        phi_EofN_deg:
            the angle (east of north) of rotation in the 2-D,
            observational plane
        zdist:
            a measure of the distance to the galaxy in question as calculated
            by the shift in H-alpha flux
            
        file_name:
            a string representation of the galaxy in question in the 
            following format: manga-[PLATE]-[IFUID].Pipe3D.cube.fits.gz
            
        start:
            the start time of the main script to test for performance
            
    @return:
        data_table:
            a tuple containing the deprojected distance and the maximum and
            minimum velocities at that radius
    """
    ################################################
    # Create a meshgrid for all coordinate points  #
    #    based on the dimensions of the H-alpha    #
    #    velocity numpy array.                     #
    ################################################
    X_RANGE = np.arange(0, len( Ha_vel[0]), 1)
    Y_RANGE = np.arange(0, len( Ha_vel[:, 0]), 1)
    X_COORD, Y_COORD = np.meshgrid( X_RANGE, Y_RANGE)


    #######################################################
    # Determine optical center via the max luminosity in  #
    #    the visual band.                                 #
    #######################################################
    img = v_band
        
    optical_center = np.argwhere( img.max() == img)
    x_center = optical_center[0, 1] # [0, 0] would return row 
    y_center = optical_center[0, 0] #    position which varies 
                                    #    with y thus the 
                                    #    indicies are "swapped"
                                        
    #########################################################
    # DIAGNOSTICS:                                          #
    #-------------------------------------------------------#
    # print("(", x_center, ",", y_center, ")")              #
    #-------------------------------------------------------#
    # Plot visual-band image.                               #
    #                                                       #
    # plt.figure(11)                                        #
    # plt.imshow( img,                                      #
    #            origin='lower')                            #
    # plt.colorbar()                                        #
    #-------------------------------------------------------#
    # Plot H-alpha velocity field before systemic redshift  #
    #   subtraction.                                        #
    #                                                       #
    # plt.figure(12)                                        #
    # plt.imshow( Ha_vel,                                   #
    #            cmap='bwr', origin='lower',                #
    #            vmin=11600, vmax=12000)                    #
    # plt.colorbar()                                        #
    #########################################################
    
    #################################################
    # Convert pixel distance to physical distance.  #
    #################################################
    dist_to_galaxy = ( zdist * const.c.to('km/s') / H_0) *\
        (1000 * u.kpc / ( u.km / u.s))
    pix_scale_factor = dist_to_galaxy * np.tan( MANGA_FIBER_DIAMETER)
    

    #################################################
    # Place a mask on all data points that equal 0  #
    #    (excluding the galactic center) and        #
    #    subtract the systemic velocity from the    #
    #    actual data points.                        #
    #################################################
    is_a_data_point = Ha_vel != 0
    sys_vel = Ha_vel[ y_center, x_center]
    Ha_vel[ is_a_data_point] -= sys_vel
    global_max = np.max( Ha_vel)
    global_min = np.min( Ha_vel)
        
    is_an_end_point = is_a_data_point == False
    is_an_end_point[ y_center, x_center] = False

    ##############################################################
    # DIAGNOSTICS:                                               #
    #------------------------------------------------------------#
    # print("Systemic Velocity:", sys_vel)                       #
    # print("Absolute MAX:", global_max)                         #
    # print("Absolute min:", global_min)                         #
    #------------------------------------------------------------#
    # Plot the data points that signal to stop taking data.      #
    #    Note: yellow purple pixels represent actual data        #
    #                                                            #
    # plt.figure(21)                                             #
    # plt.imshow( is_an_end_point, origin='lower')               #
    #------------------------------------------------------------#
    # Plot H-alpha velocity field with redshift subtracted.      #
    #                                                            #
    # plt.figure(22, figsize=(15,15))                            #
    # plt.imshow( Ha_vel,                                        #
    #            cmap='bwr', origin='lower', vmin=-60, vmax=60)  #
    # plt.grid()                                                 #
    # plt.colorbar()                                             #
    ##############################################################

    ########################################################
    # Initialization code to draw the elliptical annuli,   #
    #    create the necessary arrays to document the       #
    #    .fits file's max velocity abd min velocity to     #
    #    create the rotation curve for each respective     #
    #    galaxy, and normalize 2D arrays for the max       #
    #    and min velocity so as to check for gas bubbles.  #
    ########################################################
    phi = math.radians( 90 - ( phi_EofN_deg / u.deg)) * u.rad
    
    x_diff = X_COORD - x_center
    y_diff = Y_COORD - y_center
    
    ellipse = ( x_diff*np.cos( phi) - y_diff*np.sin( phi))**2 \
    + ( x_diff*np.sin( phi) + y_diff*np.cos( phi))**2 / ( axes_ratio)**2
        
    pix_theta = np.arctan2( y_diff, x_diff)
      
    vel_contour_plot = np.zeros(( len(X_RANGE), len(Y_RANGE)))

    ##############################################################
    # DIAGNOSTICS:                                               #
    #------------------------------------------------------------#
    # inclination_angle = math.degrees( np.arccos( axes_ratio))  #
    # phi_deg = ( 90 - phi_EofN_deg / u.deg) * u.deg             #
    #                                                            #
    # print("Angle of Inclination:", inclination_angle)          #
    # print("phi:", phi_deg),                                    #
    #       "\n-----------------------------------\n")           #
    #------------------------------------------------------------#
    # Plot the angle of each pixel with respect to the positive  #
    #    x-axis.                                                 #
    # Note: ranges from -pi to pi                                #
    #                                                            #
    # plt.figure(31)                                             #
    # plt.imshow( pix_theta, origin='lower')                     #
    # plt.colorbar()                                             #
    ##############################################################
    
    rot_curve_max_vel = []
    rot_curve_min_vel = []
    rot_curve_dist = []
    
    min_vel_coord_x = -1
    min_vel_coord_y = -1
    max_vel_coord_x = -1
    max_vel_coord_y = -1
    
    dR = 2
    R = 2
    check_range = ( math.pi / 8)
    percentage_check = 0.01 * min( global_max, abs( global_min))
    counter = 0
    
    #########################################################
    # Construct rotation curve for the galaxy in question.  #
    #    Note: further details provided in each section     #
    #########################################################
    valid_data = True
    while valid_data:
        #####################################################
        # Define an eliptical annulus and calculate the     #
        #    maximum and minimum velocities at each radii.  #
        #####################################################
        pix_between_annuli = np.logical_and(
                (R-dR)**2 <= ellipse, 
                ellipse < R**2)
        max_vel_at_annulus = np.max(
                Ha_vel[ pix_between_annuli])
        min_vel_at_annulus = np.min(
                Ha_vel[ pix_between_annuli])
        
        ###################################################
        # Plot the pixels at the current annulus.         #
        #                                                 #
        # plt.figure(41)                                  #
        # plt.imshow(pix_between_annuli, origin='lower')  #
        ###################################################
        
        ###################################################
        # Conditional statement to stop taking data for   #
        #    rotation curve on grounds of hitting false   #
        #    data points along with printable output      #
        #    (see commented out portion directly below)   #
        #    to indiciate as such.                        #
        #~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~#
        
        if np.any( pix_between_annuli[ is_an_end_point]):  
            valid_data = False      
            
        #~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~#    
        #     print("YOU HIT FALSE DATA at R =", R,       #
        #           "                   | \n----------",  #
        #           "---------------------------------",  #
        #           "-----|\n")                           #
        ###################################################
            
        ##########################################################
        # Conditional statement to continue checking             #
        #    if there is non-anomalous data (i.e. bubbles        #
        #    of gas circling at large radii) if no false         #
        #    data points along with printable output (see        #
        #    commented out poriton directly below)               #
        #    have already been encountered.                      #
        #                                                        #
        if valid_data:                                           #
        #     print("TESTING FOR ANOMALOUS DATA",                #
        #           "\n---------------------------------------") #
        #~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ #
        
        ####################################################
        # Find the coordinates of the maximum and minimum  #
        #    for a given annulus and normalize theta such  #
        #    that the location for the max and min         #
        #    corresponds with an angle of 0 for each       #
        #    respective measurement.                       #
        ####################################################
            max_vel_coord_x = np.argwhere(                                 
                    Ha_vel[ pix_between_annuli].max() == Ha_vel)[0][1]          
            max_vel_coord_y = np.argwhere(                                 
                    Ha_vel[ pix_between_annuli].max() == Ha_vel)[0][0]          
            max_pix_theta = pix_theta[ max_vel_coord_y, 
                                      max_vel_coord_x]    
            
            min_vel_coord_x = np.argwhere(                                 
                    Ha_vel[ pix_between_annuli].min() == Ha_vel)[0][1]          
            min_vel_coord_y = np.argwhere(                                 
                    Ha_vel[ pix_between_annuli].min() == Ha_vel)[0][0]          
            min_pix_theta = pix_theta[ min_vel_coord_y, 
                                      min_vel_coord_x]     
                                                    
            pix_theta_rotated_max = pix_theta - max_pix_theta
            pix_theta_rotated_max[
                pix_theta_rotated_max <= -math.pi] += 2*math.pi
            pix_theta_rotated_max[
                pix_theta_rotated_max >= math.pi] -= 2*math.pi
            pix_theta_rotated_min = pix_theta - min_pix_theta
            pix_theta_rotated_min[
                pix_theta_rotated_min <= -math.pi] += 2*math.pi
            pix_theta_rotated_min[  
                pix_theta_rotated_min >= math.pi] -= 2*math.pi
                                                                       
            ###############################################  
            # For a defined angular range, check for gas  #  
            #    bubbles and anomalies; check the pixels  #
            #    at each annulus to create a flag for     #
            #    when we hit anomolas data.               #
            ###############################################
            check_max = np.logical_and(
                pix_theta_rotated_max >= -check_range, 
                pix_theta_rotated_max <= check_range)
            check_min = np.logical_and(
                pix_theta_rotated_min >= -check_range, 
                pix_theta_rotated_min <= check_range)
        
            check_max_annulus = np.logical_and(
                check_max, 
                pix_between_annuli)
            check_min_annulus = np.logical_and(
                check_min, 
                pix_between_annuli)

            ####################################################
            # Conditional statements to stop data colleciton   #
            #    if anomalous data is encountered. Commented   #
            #    out print statements are included in each     #
            #    conditional branch as a "tracer" to follow    #
            #    the algorithm. The first statement checks     #
            #    if there is anomalous data around the max     #
            #    at the given annulus. If this evaluates to    #
            #    false, the statement short circuits and does  #
            #    not test for anomalous data around the min    #
            #    at the given annulus.                         #
            ####################################################
          
            if np.logical_and( np.any( Ha_vel[ check_max_annulus] < 0),
                not( np.any( abs( Ha_vel[ check_max_annulus]) < 
                    percentage_check)) ):            
                valid_data = False 
                print("GAS BUBBLE AROUND 'MAX'", 
                    "(not tested around min) at R = ", R)
                
            elif np.logical_and( np.any( Ha_vel[ check_min_annulus] > 0), 
                not( np.any( abs( Ha_vel[ check_min_annulus]) < 
                    percentage_check)) ):
                valid_data = False
                print("GAS BUBBLE AROUND 'MIN' at R =", R)
    
        #####################################################
        # This final condition statement of the while       #
        #    loop adds data to the rotation curve list      #
        #    if no false or anomalous data has been         #
        #    encountered. The print statement               #
        #    commented out directly below acts as a         #
        #    "tracer" to follow the while loop as it        #
        #    progresses through its iterations.             #
        #~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~#
        
        if valid_data:
            
        #~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~#
        #     print("GATHERING VALID DATA AT R =", R)       #
        #     print( np.argwhere( pix_between_annuli))      #
        #####################################################
        
            rot_curve_max_vel.append( max_vel_at_annulus)
            rot_curve_min_vel.append( abs( min_vel_at_annulus))
            rot_curve_dist.append( R * pix_scale_factor / u.kpc)
           
            vel_contour_plot[ pix_between_annuli] = Ha_vel[ pix_between_annuli]
            
            R += dR
            counter += 1
        
        ###############################################################
        # DIAGNOSTICS (PER ITERATION):                                #
        #    WARNING: These diagnostics are nested within the while   #
        #             loop and reflect the current iteration,         #
        #             annulus, minima, maxima, etc.                   #
        #             The figures will correspond with the last       #
        #             iteration ran in the loop unless a break        #
        #             statement is inserted.                          #
        #-------------------------------------------------------------#
        # The statements in this subset contain information about     #
        #    the minimum and maximum at a given annulus. These        #
        #    statements also show how theta is changed throughout     #
        #    the normalization process.                               #
        #                                                             #
        # plt.figure(51, figsize=(5,5))                               #
        # plt.title('Theta Before Normalization')                     #
        # plt.imshow( pix_theta, origin='lower')                      #  
        # plt.colorbar()                                              #
        #                                                             #
        # print("Max velocity at annulus: ",                          #
        #       max_vel_at_annulus)                                   #
        # print("Current max velocity coordinates: (",                #
        #           max_vel_coord_x, ",", max_vel_coord_y, ")")       #
        # print("Original theta for pixel with MAX velocity:",        #
        #       max_pix_theta, "\n")                                  #
        # plt.figure(52)                                              #
        # plt.title('Normalized to Max')                              #
        # plt.imshow( pix_theta_rotated_max, origin='lower')          #  
        # plt.colorbar()                                              #
        #                                                             #
        # print("Min velocity at annulus:",                           #
        #       min_vel_at_annulus, end='\n\n')                       #
        # print("Current min velocity coordinates: (",                #
        #       min_vel_coord_x, ",", min_vel_coord_y, ")")           #
        # print("Original theta for pixel with MIN velocity:",        #
        #       min_pix_theta, "\n")                                  #
        # plt.figure(53)                                              #
        # plt.title('Normalized to Min')                              #
        # plt.imshow( pix_theta_rotated_min, origin='lower')          #  
        # plt.colorbar()                                              #
        #-------------------------------------------------------------#
        # These statements show the process of checking each annulus  #
        #    for anomalous data. Included are the pixels checked for  #
        #    anomalies, the outcome of the conditional statements     #
        #    detailing if there are any anomalies and if so, where    #
        #    they are caught, and finally, a graphical                #
        #    representation is given to see which pixels were         #
        #    checked in this process.                                 #
        #                                                             #
        # print("MAX\n------------------------")                      #
        # print("Check values:\n", Ha_vel[ check_max_annulus])        #
        # print("Less than zero:", np.any(                            #
        #     Ha_vel[ check_max_annulus] < 0))                        #
        # print("Doesn't cross 'zero' boundry:", not( np.any(         #
        #     abs( Ha_vel[ check_max_annulus]) < percentage_check)),  #
        #       end='\n\n')                                           #
        # plt.figure(61, figsize=(5,5))                               #
        # plt.imshow( check_max_annulus, origin='lower')              #
        #                                                             #
        # print("MIN\n------------------------")                      #
        # print("Check values:\n", Ha_vel[ check_min_annulus])        #
        # print("Greater than zero:", np.any(                         #
        #     Ha_vel[ check_min_annulus] > 0))                        #
        # print("Doesn't cross zero boundry:", not( np.any(           #
        #     abs( Ha_vel[ check_min_annulus]) < percentage_check)),  #
        #       end='\n\n' )                                          #
        # plt.figure(62, figsize=(5,5))                               #
        # plt.imshow( check_min_annulus, origin='lower')              #
        ###############################################################

    ##################################################################
    # DIAGNOSTICS (FOR ENTIRE LOOP):                                 #
    # This subset contains general information about the parameters  #
    #    used in the execution of the while loop. It is only printed #
    #    once at the termination of the while loop.                  #
    #                                                                #
    # print("Starting Pixel Radius:", R)                             #
    # print("Step Size:", dR,                                        #
    #       "\n------------------------------------------------|")   #
    #                                                                #
    # Angular range in which to check for potential anomalous data:  #
    # print("Theta Check Range:", check_range)                       #
    #                                                                #
    # As the data 'zeros' are not actually 0, 1% of the smaller      #
    #    of the absolute max and absolute min of the entire dataset  #
    #    has been used to test for 'zeros':                          #
    # print("Zero Constitution:", percentage_check)                  #
    ##################################################################
    
    ##################################################
    # All further statements with the exception of   #
    #    the return statement are used to give       #
    #    information on the terminating loop         #
    #    for data collection. Figures are generated  #
    #    that show the phi from the NSA Catalog,     #
    #    as well as the pixels used from the         #
    #    H-alpha velocity field to generate the      #
    #    min and max rotation curves. An image in    #
    #    the visual band is also given with phi      #
    #    plotted to verify that the phi derived      #
    #    from the sersic fit in the visual band (as  #
    #    done in the NSA Catalog) lines up with the  #
    #    kinematic major axis of the H-alpha         #
    #    velocity field. The caught, anomalous max   #
    #    and min for the while loop are also         #
    #    printed to verify  the algorithm is         #
    #    working correctly.                          #
    ##################################################

    # m = np.tan( phi)
    # X_STEP = np.arange(0, len( X_RANGE), 1)
    # y_vals = m * ( X_STEP - x_center) + y_center
        
    # plt.figure(71, figsize=(5, 5))
    # plt.title('H-alpha Velocity Field w/ Phi Plotted')
    # plt.imshow( vel_contour_plot, origin='lower', 
    #    vmin = -150, vmax=150, cmap='bwr')
    # plt.xlim(0, len(X_RANGE))
    # plt.ylim(0, len(Y_RANGE))
    # plt.colorbar()
    # plt.plot( X_STEP, y_vals, '--')
    # plt.plot( x_center, y_center, 'go')
    # plt.plot( min_vel_coord_x, min_vel_coord_y, 'c^')
    # plt.plot( max_vel_coord_x, max_vel_coord_y, 'mv')
        
    # plt.figure(72, figsize=(5, 5))
    # plt.title('Visual Band w/ Phi Plotted')
    # plt.imshow( img, origin='lower')
    # plt.xlim(0, len(X_RANGE))
    # plt.ylim(0, len(Y_RANGE))
    # plt.colorbar()
    # plt.plot( X_STEP, y_vals, '--')
    # plt.plot( x_center, y_center, 'go')
    # plt.plot( min_vel_coord_x, min_vel_coord_y, 'c^')
    # plt.plot( max_vel_coord_x, max_vel_coord_y, 'mv')
            
#    plt.figure(999)
#    plt.plot( rot_curve_dist, rot_curve_max_vel, 'ro')
#    plt.plot( rot_curve_dist, rot_curve_min_vel, 'bo')
#    plt.ylabel('Deprojected Velocity (m/s)')
#    plt.xlabel('Deprojected Radius (kpc)')
#    plt.show()
    
    dist_col = Column( rot_curve_dist)
    max_vel_col = Column( rot_curve_max_vel)
    min_vel_col = Column( rot_curve_min_vel)
    
    data_table = QTable([ dist_col *  u.kpc,
                         max_vel_col * ( u.m / u.s),
                         min_vel_col * ( u.m / u.s)],
                 names = ['Deprojected Distance',
                          'Max Velocity', 
                          'Min Velocity'])

    return data_table                    

def write(file_name, data_table, LOCAL_PATH, ROT_CURVE_MASTER_FOLDER,
          ROT_CURVE_DATA_INDICATOR, start):
    """Write data_table with an ascii-commented header to a .txt file 
    specified by the LOCAL_PATH, ROT_CURVE_MASTER_FOLDER, output_data_folder,
    output_data_name, and ROT_CURVE_DATA_INDICATOR variables.
     
    @param:
        file_name:
            a string representation of the galaxy in question in the 
            following format: manga-[PLATE]-[IFUID].Pipe3D.cube.fits.gz
        
        data_table:
            a tuple containing the deprojected distance and the maximum and 
            minimum velocities at that radius
        
        LOCAL_PATH: string specifying the path the main script is executed in
        
        ROT_CURVE_MASTER_FOLDER:
            name in which to store the data subfolders into
            
        ROT_CURVE_DATA_INDICATOR:
            the extension of the file before '.txt' that identifies the
            respective file as a rotation curve data file
            
        start:
            the start time of the main script to test for performance
    """
    
    output_data_folder_start = file_name.index('-') + 1
    output_data_folder_end = file_name.index('-', output_data_folder_start + 1)
    output_data_folder = "/" + file_name[ 
            output_data_folder_start: output_data_folder_end]
        
    
    output_data_name_start = output_data_folder_start
    output_data_name_end = file_name.index('P', output_data_name_start + 1)
    output_data_name = "/" + file_name[
            output_data_name_start: output_data_name_end - 1]
    
    write_path = LOCAL_PATH + ROT_CURVE_MASTER_FOLDER + output_data_folder
    
    if not os.path.exists( write_path):
        os.makedirs( write_path)
    
    ascii.write( data_table, 
                write_path \
                + output_data_name + ROT_CURVE_DATA_INDICATOR + '.txt', 
                format = 'ecsv',
                overwrite = True)