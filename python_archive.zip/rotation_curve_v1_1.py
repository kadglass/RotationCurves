#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Created on Wed Jul 13 2018
@author: Jacob A. Smith
@version: 1.1

Analyzes mainly face-on galaxies in an attempt to compute the rotation
curve (rotational velocity as a function of radius).

To download data: http://www.sdss.org/dr14/manga/manga-data/data-access/
"""
########################################
# Optional import statement to import  #
#    matplotlib.pyplot if needed for   #
#    graphing diagnostics.             #
########################################
import matplotlib.pyplot as plt

import os.path

import math
import numpy as np
import warnings
warnings.simplefilter('ignore', np.RankWarning)

from astropy.io import fits, ascii
from astropy.coordinates import SkyCoord
from astropy.table import QTable, Column
import astropy.units as u
import astropy.constants as const

######################
# Declare constants. #
######################

H_0 = 100       # Hubble's Constant in units of km /s /Mpc

MANGA_FIBER_DIAMETER = 9.69627362219072e-06   # angular fiber diameter
                                              #   (2") in radians                                        

def extract_data( file_name):
    """Open the MaNGA .fits file and extract data.
    
    @param:
        file_name:
            a string representation of the galaxy in question in the 
            following format: manga-[PLATE]-[IFUID].Pipe3D.cube.fits.gz
    
    @return:
        Ha_vel:
            an n-D numpy array containing the H-alpha velocity field data
        
        v_band[0]:
            an n-D numpy array containing the visual-band flux data
        
        manga_plate:
            int representation of the manga plate number of observation
            
        manga_fiberID:
            int representation of the manga fiber ID of observation
            
        gal_ra:
            the galaxy in question's righthand ascension
            
        gal_dec:
            the galaxy in question's declination
    """
    main_file = fits.open( file_name)
    
    flux_elines = main_file[3].data
    Ha_vel = flux_elines[102]
    
    v_band = main_file[1].data
    org_hdr = main_file[0].header
    
    main_file.close()
    
    manga_plate = org_hdr['PLATEID']
    manga_fiberID = org_hdr['IFUDSGN']
    gal_ra = org_hdr['OBJRA']
    gal_dec = org_hdr['OBJDEC']
    
    return Ha_vel, v_band[0], v_band[13], manga_plate, manga_fiberID, \
                gal_ra, gal_dec
    

def match( gal_ra, gal_dec, cat_coords):
    """Match the galaxy in question to the NSA Catalog.
    WARNING: this function takes a substantially long time; it must match the
    RA and DEC of the galaxy in question to a singluar entry in the entire
    NASA-Sloan-Atlas catalog.
    
    @param:
        gal_ra:
            the galaxy in question's righthand ascension
        
        gal_dec:
            the galaxy in question's declination
        
        cat_coords:
            SkyCoord master list containing all of the righthand ascension
            and declination for the galaxies contained in the NSA
            catalog
            ATTN: cat_coords must be a list of SkyCoord objects

    @return:
        idx:
            the NSA catalog integer index of the galaxy in question
    """
    gal_coord = SkyCoord( ra = gal_ra * u.degree,
                         dec = gal_dec * u.degree)

    idx = gal_coord.match_to_catalog_sky( cat_coords)[0]
    
    ###########################################################################
    # DIAGNOSTICS:                                              
    #--------------------------------------------------------------------------
#    print(gal_coord)                                          
#    print("NSA index of galaxy:", idx)                        
    ###########################################################################

    return idx

def rot_curve( Ha_vel, v_band, axes_ratio, phi_EofN_deg, zdist, file_id):
    """Calculates the rotation curve (rotational velocity as a funciton of
    deprojected distance) of the galaxy in question.
    
    @param:
        Ha_vel:
            an n-D numpy array containing the H-alpha velocity field data
        
        v_band:
            an n-D numpy array containing the visual band flux data
        
        axes_ratio:
            float representation of the ratio of the galaxy's minor axis to the
            major axis as obtained via a sersic fit of the galaxy
                    
        phi_EofN_deg:
            float representation of the angle (east of north) of rotation in 
            the 2-D, observational plane.
            NOTE: east is 'left' per astronomy conventions
            
        zdist:
            float representation of a measure of the distance to the galaxy in 
            question as calculated by the shift in H-alpha flux
            
        file_id:
            a string representation of the galaxy in question in the 
            following format: [PLATE]-[IFUID]
            
    @return:
        data_table:
            an astropy QTable containing the deprojected distance, maximum and 
            minimum velocities at that radius, average luminosities for each 
            half of the galaxy at that radius, luminosity interior to the 
            radius, and the stellar mass interior to the radius
        
        gal_stats:
            an astropy QTable containing single-valued columns of the processed
            and unprocessed luminosities, corresponding masses for such 
            luminosity measurements, and the luminosity at the center of the 
            galaxy in question
    """
    ###########################################################################
    # Create a meshgrid for all coordinate points based on the dimensions of 
    # the H-alpha velocity numpy array.                     
    ###########################################################################
    X_RANGE = np.arange(0, len( Ha_vel[0]), 1)
    Y_RANGE = np.arange(0, len( Ha_vel[:, 0]), 1)
    X_COORD, Y_COORD = np.meshgrid( X_RANGE, Y_RANGE)


    ###########################################################################
    # Determine optical center via the max luminosity in the visual band.                                 #
    ###########################################################################
    img = v_band
        
    optical_center = np.argwhere( img.max() == img)
    x_center = optical_center[0, 1] # [0, 0] would return row 
    y_center = optical_center[0, 0] #    position which varies 
                                    #    with y thus the 
                                    #    indicies are "swapped"
                                        
    ###########################################################################
    # DIAGNOSTICS:                                          
    #--------------------------------------------------------------------------
#    print("(", x_center, ",", y_center, ")")              
    #--------------------------------------------------------------------------
    # Plot visual-band image.                               
    #                                                       
    vband_image = plt.figure()  
    plt.title( file_id + ' Visual Band Image (RAW)')                                        
    plt.imshow( img, origin='lower')  
                    
    cbar = plt.colorbar( ticks = np.linspace(  0, img.max(), 6)) 
    cbar.ax.tick_params( direction='in', color='white')
    cbar.set_label(r'Luminosity [10E-17 erg s$^{-1}$ cm$^{-2}$]')
    
    plt.xticks( np.arange( 0, 80, 10))
    plt.yticks( np.arange( 0, 80, 10))
    plt.tick_params( axis='both', direction='in', color='white')
    ax = vband_image.add_subplot(111)
    ax.yaxis.set_ticks_position('both')
    ax.xaxis.set_ticks_position('both')
    plt.xlabel(r'$\Delta \alpha$ (arcsec)')
    plt.ylabel(r'$\Delta \delta$ (arcsec)')                             
    #--------------------------------------------------------------------------
    # Plot H-alpha velocity field before systemic redshift  
    #   subtraction. Galaxy velocities vary from file to file, so vmin and vmax
    #   will have to be manually adjusted for each galaxy before reshift
    #   subtraction.                                     
    #           
    vmax_input = 0
    vmin_input = 12000                                            
    ha_vel_field_raw_fig = plt.figure()  
    plt.title( file_id + " " + r'H$\alpha$ Velocity Field (RAW)')                                      
    plt.imshow( Ha_vel, cmap='bwr', origin='lower',                
               vmin = vmin_input, vmax = vmax_input)     
          
    cbar = plt.colorbar( ticks = np.linspace(vmin_input, vmax_input, 12)) 
    cbar.ax.tick_params( direction='in')
    cbar.set_label(r'$V_{ROT}$ [$km s^{-1}$]') 

    plt.xticks( np.arange( 0, 80, 10))
    plt.yticks( np.arange( 0, 80, 10))
    plt.tick_params( axis='both', direction='in')
    ax = ha_vel_field_raw_fig.add_subplot(111)
    ax.yaxis.set_ticks_position('both')
    ax.xaxis.set_ticks_position('both')
    plt.xlabel(r'$\Delta \alpha$ (arcsec)')
    plt.ylabel(r'$\Delta \delta$ (arcsec)')             
    ###########################################################################
    
    ###########################################################################
    # Convert pixel distance to physical distance.  
    ###########################################################################
    dist_to_galaxy_kpc = ( zdist * const.c.to('km/s') / H_0) *\
        (1000 * u.kpc / ( u.km / u.s)) 
    dist_to_galaxy_cm = dist_to_galaxy_kpc * 3.086E+21 * (u.cgs.cm / u.kpc)
    pix_scale_factor = dist_to_galaxy_kpc * np.tan( MANGA_FIBER_DIAMETER)

    ###########################################################################
    # Place a mask on all data points that equal 0 (excluding the galactic 
    #    center) and subtract the systemic velocity from actual data points.
    ###########################################################################
    valid_data = Ha_vel != 0
    sys_vel = Ha_vel[ y_center, x_center]
    Ha_vel[ valid_data] -= sys_vel
    
    global_max = np.max( Ha_vel)
    global_min = np.min( Ha_vel)
        
    end_point = valid_data == False    
    end_point[ y_center, x_center] = False

    ###########################################################################
    # DIAGNOSTICS:                                               
    #--------------------------------------------------------------------------
#     print("Systemic Velocity:", sys_vel)                       
#     print("Absolute MAX:", global_max)                         
#     print("Absolute min:", global_min)                         
#     print("Aggregate Luminosity of Outliers:", agg_lum_end_points)
    #--------------------------------------------------------------------------
    # Plot the data points that signal to stop taking data.      
    #    Note: yellow purple pixels represent actual data        
#    end_point_pixel_fig = plt.figure()      
#    plt.title( file_id + ' Data Points (in yellow)')                                       
#    plt.imshow( valid_data, origin='lower')  
#     
#    plt.xticks( np.arange( 0, 80, 10))
#    plt.yticks( np.arange( 0, 80, 10))
#    plt.tick_params( axis='both', direction='in')
#    ax = end_point_pixel_fig.add_subplot(111)
#    ax.yaxis.set_ticks_position('both')
#    ax.xaxis.set_ticks_position('both')
#    plt.xlabel(r'$\Delta \alpha$ (arcsec)')
#    plt.ylabel(r'$\Delta \delta$ (arcsec)')  
    #--------------------------------------------------------------------------
    # Plot H-alpha velocity field with redshift subtracted.

#    vmax_input = 250
#    vmin_input = -250                                            
#    ha_vel_field_fig = plt.figure()  
#    plt.title( file_id + r' H$\alpha$ Velocity Field (z Sub)')                                      
#    plt.imshow( Ha_vel, cmap='bwr', origin='lower',                
#               vmin = vmin_input, vmax = vmax_input)     
#          
#    cbar = plt.colorbar( ticks = np.linspace(vmin_input, vmax_input, 12)) 
#    cbar.ax.tick_params( direction='in')
#    cbar.set_label(r'$V_{ROT}$ [$km s^{-1}$]') 
#
#    plt.xticks( np.arange( 0, 80, 10))
#    plt.yticks( np.arange( 0, 80, 10))
#    plt.tick_params( axis='both', direction='in')
#    ax = ha_vel_field_fig.add_subplot(111)
#    ax.yaxis.set_ticks_position('both')
#    ax.xaxis.set_ticks_position('both')
#    plt.xlabel(r'$\Delta \alpha$ (arcsec)')
#    plt.ylabel(r'$\Delta \delta$ (arcsec)')                                   
    ###########################################################################

    ###########################################################################
    # Initialization code to draw the elliptical annuli, create the necessary 
    #    arrays to document the .fits file's max velocity and min velocity to
    #    create the rotation curve for each respective galaxy, and normalize
    #    2D arrays for the max and min velocity so as to check for gas bubbles.
    ###########################################################################
    phi = math.radians( 90 - ( phi_EofN_deg / u.deg)) * u.rad
    
    x_diff = X_COORD - x_center
    y_diff = Y_COORD - y_center
    
    ellipse = ( x_diff*np.cos( phi) - y_diff*np.sin( phi))**2 \
    + ( x_diff*np.sin( phi) + y_diff*np.cos( phi))**2 / ( axes_ratio)**2
        
    pix_theta = np.arctan2( y_diff, x_diff)
      
    vel_contour_plot = np.zeros(( len(X_RANGE), len(Y_RANGE)))

    ###########################################################################
    # DIAGNOSTICS:                                               
    #--------------------------------------------------------------------------
    # inclination_angle = math.degrees( np.arccos( axes_ratio))  
    # phi_deg = ( 90 - phi_EofN_deg / u.deg) * u.deg             
    #                                                           
#    print("Angle of Inclination:", inclination_angle)          
#    print("phi:", phi_deg, "\n-----------------------------------\n")           
    #--------------------------------------------------------------------------
    # Plot the angle of each pixel with respect to the positive x-axis.                                                 
    # Note: ranges from -pi to pi                                
    #                                                          
#    plt.figure()                                             
#    plt.imshow( pix_theta, origin='lower')                     
#    plt.colorbar()                                             
    ###########################################################################
    
    lum_center_sol = img[ y_center, x_center] / 3.839E50   # in units of 
                                                           #  solar luminosity
    # normalize for distance to galaxy in cm                                                      
    lum_center_sol *= 4 * np.pi * (dist_to_galaxy_cm / u.cgs.cm)**2  
#    print("lum_center_sol:", lum_center_sol)
    
    min_vel_coord_x = -1
    min_vel_coord_y = -1
    max_vel_coord_x = -1
    max_vel_coord_y = -1
    
    dR = 2
    R = 2
    check_range = ( math.pi / 8)
    percentage_check = 0.01 * min( global_max, abs( global_min))
    counter = 0
    
    ###########################################################################
    # Construct rotation curve for the galaxy in question.  
    #    NOTE: further details provided in each section     
    ###########################################################################
    rot_curve_max_vel = []
    rot_curve_min_vel = []
    rot_curve_vel_diff = []
    rot_curve_vel_avg = []
    rot_curve_dist = []
    lum_curve_max = []
    lum_curve_min = []
    lum_interior = []
    stellar_mass_interior = []
    lum_interior_prev = 0
    
    valid_data = True
    while valid_data:
        #######################################################################
        # Define an eliptical annulus and calculate the maximum and minimum 
        #    velocities at each radii as well as the luminosity for both sides
        #    of each radii which represent the positive and negative rotation
        #    velocities for the galaxy in question.
        #######################################################################
        pix_between_annuli = np.logical_and(
                (R-dR)**2 <= ellipse, 
                ellipse < R**2)
        
        max_vel_at_annulus = np.max(
                Ha_vel[ pix_between_annuli])         
        
        min_vel_at_annulus = np.min(
                Ha_vel[ pix_between_annuli]) 

        #######################################################################
        # NOTE: the boolean conditions for calculating luminosity as a function
        #       of deprojected distance have been defined to have the positive
        #       side for the first iteration of the loop to take the center 
        #       luminosity into account; the negative side of the galaxy does
        #       not have this feature.
        #######################################################################
        annular_positive_vel = np.logical_and( pix_between_annuli, Ha_vel >= 0)
        annular_negative_vel = np.logical_and( pix_between_annuli, Ha_vel < 0)           
        
        lum_max_tot = 0
        lum_max_len = 0
        lum_min_tot = 0
        lum_min_len = 0
        
        for pixel in img[ annular_positive_vel]:
            lum_max_tot += pixel            
            lum_max_len += 1
            
        for pixel in img[ annular_negative_vel]:
            lum_min_tot += pixel            
            lum_min_len += 1
            
        lum_interior_temp = lum_interior_prev + (lum_max_tot + lum_min_tot)
        lum_interior_prev += (lum_max_tot + lum_min_tot)
         
        if lum_max_len == 0 or lum_min_len == 0:
            lum_max_avg = 0
            lum_min_avg = 0
        else:
            lum_max_avg = lum_max_tot / lum_max_len    
            lum_min_avg = lum_min_tot / lum_min_len  
        
        print("lum_interior_temp [10E-17 erg/s/cm^2]: ", lum_interior_temp)
        
        #######################################################################
        # DIAGNOSTICS: 
        #----------------------------------------------------------------------
        # Plot the pixels at the current annulus.        
        #                                                
#        current_pix_fig = plt.figure()           
#        plt.title('Pixels at ' + str(R - dR) + ' < R < ' + str(R))                       
#        plt.imshow(pix_between_annuli, origin='lower')  
#
#        plt.xticks( np.arange( 0, 80, 10))
#        plt.yticks( np.arange( 0, 80, 10))
#        plt.tick_params( axis='both', direction='in')
#        ax = current_pix_fig.add_subplot(111)
#        ax.yaxis.set_ticks_position('both')
#        ax.xaxis.set_ticks_position('both')
#        plt.xlabel(r'$\Delta \alpha$ (arcsec)')
#        plt.ylabel(r'$\Delta \delta$ (arcsec)') 
        #----------------------------------------------------------------------
        # Plot the pixels for the positive and negative rotation velocity sides
        #     for the galaxy in question.
        #    
#        annular_pos_fig = plt.figure(411, figsize=(5, 5))
#        plt.title(r'Pixels Processed for Max Luminosity Curve')
#        plt.imshow( annular_positive_vel, origin='lower')
#        ax = annular_pos_fig.add_subplot(111)
#    
#        plt.xticks( np.arange( 0, 80, 10))
#        plt.tick_params( axis='both', direction='in')
#        ax.yaxis.set_ticks_position('both')
#        ax.xaxis.set_ticks_position('both')
#        plt.xlabel(r'$\Delta \alpha$ (arcsec)')
#        plt.ylabel(r'$\Delta \delta$ (arcsec)') 
#
#        annular_neg_fig = plt.figure(412, figsize=(5, 5))
#        plt.title(r'Pixels Processed for Min Luminosity Curve')
#        plt.imshow( annular_negative_vel, origin='lower')
#        ax = annular_neg_fig.add_subplot(111)
#    
#        plt.xticks( np.arange( 0, 80, 10))
#        plt.tick_params( axis='both', direction='in')
#        ax.yaxis.set_ticks_position('both')
#        ax.xaxis.set_ticks_position('both')
#        plt.xlabel(r'$\Delta \alpha$ (arcsec)')
#        plt.ylabel(r'$\Delta \delta$ (arcsec)')
        #######################################################################
        
        #######################################################################
        # Conditional statement to stop taking data for rotation curve on 
        #    grounds of hitting false data points along with printable output
        #    (see commented out portion directly below) to indiciate as such.                        #
        #~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ 
        
        if np.any( pix_between_annuli[ end_point]):  
            valid_data = False      
            
        #~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~    
#            print("YOU HIT FALSE DATA at R =", R, "                   |",      
#                  "\n------------------------------------------------|\n")                           
        #######################################################################
            
        #######################################################################
        # Conditional statement to continue checking if there is non-anomalous 
        #    data (i.e. bubbles of gas circling at large radii) if no false    
        #    data points along with printable output (see commented out
        #    portiondirectly below) have already been encountered.    
        #                                                        
        if valid_data:                                           
#            print("TESTING FOR ANOMALOUS DATA",                
#                  "\n---------------------------------------") 
        #~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ 
        
        #######################################################################
        # Find the coordinates of the maximum and minimum for a given annulus 
        #    and normalize theta such that the location for the max and min         
        #    corresponds with an angle of 0 for each respective measurement.                       
        #######################################################################
            max_vel_coord_x = np.argwhere(                                 
                    Ha_vel[ pix_between_annuli].max() == Ha_vel)[0][1]          
            max_vel_coord_y = np.argwhere(                                 
                    Ha_vel[ pix_between_annuli].max() == Ha_vel)[0][0]          
            max_pix_theta = pix_theta[ max_vel_coord_y, 
                                      max_vel_coord_x]    
            
            min_vel_coord_x = np.argwhere(                                 
                    Ha_vel[ pix_between_annuli].min() == Ha_vel)[0][1]          
            min_vel_coord_y = np.argwhere(                                 
                    Ha_vel[ pix_between_annuli].min() == Ha_vel)[0][0]          
            min_pix_theta = pix_theta[ min_vel_coord_y, 
                                      min_vel_coord_x]     
                                                    
            pix_theta_rotated_max = pix_theta - max_pix_theta
            pix_theta_rotated_max[
                pix_theta_rotated_max <= -math.pi] += 2*math.pi
            pix_theta_rotated_max[
                pix_theta_rotated_max >= math.pi] -= 2*math.pi
            pix_theta_rotated_min = pix_theta - min_pix_theta
            pix_theta_rotated_min[
                pix_theta_rotated_min <= -math.pi] += 2*math.pi
            pix_theta_rotated_min[  
                pix_theta_rotated_min >= math.pi] -= 2*math.pi
            
                                                                       
            ###################################################################  
            # For a defined angular range, check for gas bubbles and anomalies; 
            #    check the pixels at each annulus to create a flag for when we 
            #    hit anomolas data.               
            ###################################################################
            check_max = np.logical_and(
                pix_theta_rotated_max >= -check_range, 
                pix_theta_rotated_max <= check_range)
            check_min = np.logical_and(
                pix_theta_rotated_min >= -check_range, 
                pix_theta_rotated_min <= check_range)
        
            check_max_annulus = np.logical_and(
                check_max, 
                pix_between_annuli)
            check_min_annulus = np.logical_and(
                check_min, 
                pix_between_annuli)

            ###################################################################
            # Conditional statements to stop data colleciton if anomalous data 
            #    is encountered. Commented out print statements are included in
            #    each conditional branch as a "tracer" to follow the algorithm. 
            #    The first statement checks if there is anomalous data around 
            #    the max at the given annulus. If this evaluates to false, the 
            #    statement short circuits and does not test for anomalous data 
            #    around the min at the given annulus.
            ###################################################################
          
            if np.logical_and( np.any( Ha_vel[ check_max_annulus] < 0),
                not( np.any( abs( Ha_vel[ check_max_annulus]) < 
                    percentage_check)) ):            
                valid_data = False 
                print("GAS BUBBLE AROUND 'MAX'", 
                    "(not tested around min) at R = ", R)
                
            elif np.logical_and( np.any( Ha_vel[ check_min_annulus] > 0), 
                not( np.any( abs( Ha_vel[ check_min_annulus]) < 
                    percentage_check)) ):
                valid_data = False
                print("GAS BUBBLE AROUND 'MIN' at R =", R)
    
        #######################################################################
        # This final condition statement of the while loop adds data to the
        #    rotation curve list if no false or anomalous data has been         
        #    encountered. In addition, extract luminosity at the coordinates 
        #    cooresponding to the minimum and maximum velocities and add that
        #    data to its respective list.
        #
        # The print statement commented out directly below acts as a "tracer" 
        #    to follow the while loop as it progresses through its iterations.
        # ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~
        
        if valid_data:
            
        # ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~
        #     print("GATHERING VALID DATA AT R =", R)       
        #     print( np.argwhere( pix_between_annuli))      
        #######################################################################
        
            rot_curve_max_vel.append( max_vel_at_annulus)
            rot_curve_min_vel.append( abs( min_vel_at_annulus))
            
            ###################################################################
            # Velocity Curve Discrepancy Fixes   
            #    Originally, we had throught to take the difference of the 
            #    maximum minus the minimum rotation curve; however, this
            #    sometimes led to a negative discrpancy. We have simply
            #    normalized this difference to always be a positive difference
            #    bwtween the two rotation curves.
            ###################################################################
            rot_curve_vel_diff.append( abs( max_vel_at_annulus - \
                                       abs( min_vel_at_annulus)))
            rot_curve_vel_avg.append(
                    ( max_vel_at_annulus + abs( min_vel_at_annulus)) / 2)
            ###################################################################
            
            rot_curve_dist.append( R * pix_scale_factor / u.kpc)
            lum_curve_max.append( lum_max_avg \
                                 *4* np.pi * (dist_to_galaxy_cm / u.cgs.cm)**2\
                                     / 3.839E50)
            lum_curve_min.append( lum_min_avg \
                                 *4* np.pi * (dist_to_galaxy_cm / u.cgs.cm)**2\
                                     / 3.839E50)
            lum_interior.append( lum_interior_temp \
                                 *4* np.pi * (dist_to_galaxy_cm / u.cgs.cm)**2\
                                     / 3.839E50)
            stellar_mass_interior.append(
                    (lum_interior_temp * (4 * np.pi * \
                                         (dist_to_galaxy_cm / u.cgs.cm)**2)\
                                      / 3.839E50)**(1/3.5))
           
            vel_contour_plot[ pix_between_annuli] = Ha_vel[ pix_between_annuli]
            
            R += dR
            counter += 1
        
        #######################################################################
        # DIAGNOSTICS (PER ITERATION):                                
        #    WARNING: These diagnostics are nested within the while loop and 
        #             reflect the current iteration,vannulus, minima, maxima, 
        #             etc. The figures will correspond with the last iteration 
        #             ran in the loop unless a break statement is inserted.                          
        #----------------------------------------------------------------------
        # The statements in this subset contain information about the minimum 
        #    and maximum at a given annulus. These statements also show how 
        #    theta is changed throughout the normalization process.                               
        #                                                             
#         plt.figure()                               
#         plt.title('Theta Before Normalization')                     
#         plt.imshow( pix_theta, origin='lower')                      
#         plt.colorbar()                                              
#                                                                     
#         print("max_vel_at_annulus: ", max_vel_at_annulus)                                   
#         print("Current max velocity coordinates: (",                
#                   max_vel_coord_x, ",", max_vel_coord_y, ")")       
#         print("Original theta for pixel with MAX velocity:",
#               max_pix_theta, "\n")  
#                                        
#         plt.figure()                                              
#         plt.title('Theta Normalized to Max')                              
#         plt.imshow( pix_theta_rotated_max, origin='lower')          
#         plt.colorbar()                                              
#                                                                     
#         print("min_vel_at_annulus:", min_vel_at_annulus, end='\n\n')                       
#         print("Current min velocity coordinates: (",                
#               min_vel_coord_x, ",", min_vel_coord_y, ")")           
#         print("Original theta for pixel with MIN velocity:",        
#               min_pix_theta, "\n")    
#                                      
#         plt.figure()                                              
#         plt.title('Theta Normalized to Min')                              
#         plt.imshow( pix_theta_rotated_min, origin='lower')          
#         plt.colorbar()                                              
        #----------------------------------------------------------------------
        # These statements show the process of checking each annulus for 
        #    anomalous data. Included are the pixels checked for anomalies, 
        #    the outcome of the conditional statements detailing if there are 
        #    any anomalies and if so, where they are caught, and finally, a 
        #    graphical representation is given to see which pixels were checked 
        #    in this process.                                 
        #                                                             
        # print("MAX\n------------------------")                      
        # print("Check values:\n", Ha_vel[ check_max_annulus])        
        # print("Less than zero:", np.any(                            
        #     Ha_vel[ check_max_annulus] < 0))                        
        # print("Doesn't cross 'zero' boundry:", not( np.any(         
        #     abs( Ha_vel[ check_max_annulus]) < percentage_check)),  
        #       end='\n\n')                                           
        # plt.figure()                               
        # plt.imshow( check_max_annulus, origin='lower')              
        #                                                             
        # print("MIN\n------------------------")                      
        # print("Check values:\n", Ha_vel[ check_min_annulus])
        # print("Greater than zero:", np.any(
        #     Ha_vel[ check_min_annulus] > 0))
        # print("Doesn't cross zero boundry:", not( np.any(
        #     abs( Ha_vel[ check_min_annulus]) < percentage_check)),
        #       end='\n\n' )
        # plt.figure()
        # plt.imshow( check_min_annulus, origin='lower')
        #######################################################################
    
    ###########################################################################
    # Extract the luminosity of the data processed and data not processed in 
    #    extracting rotation curve data. Also, estimate the mass of each
    #    respective region via L = m**3.5 which is based on the assumption that
    #    90% of the light found in spiral galaxies comes from main sequence
    #    stars, and because we know the chemical composition of such stars, we
    #    can therefore estimate the mass.
    #
    # NOTE: the units of luminosity are converted to solar luminosity and the
    #           units of mass are also in solar mass.
    ###########################################################################
    
    lum_processed = 0
    for pixel in img[ ellipse < R**2]:
        lum_processed += pixel
        
    lum_unprocessed = 0
    for pixel in img[ ellipse >= R**2]:
        lum_unprocessed += pixel
        
    lum_processed *= 4* np.pi * (dist_to_galaxy_cm / u.cgs.cm)**2 / 3.839E50
    lum_unprocessed *= 4* np.pi * (dist_to_galaxy_cm / u.cgs.cm)**2 / 3.839E50 
    mass_processed = lum_processed**(1/3.5)
    mass_unprocessed = lum_unprocessed**(1/3.5)
    
    ###########################################################################
    # DIAGNOSTICS (FOR ENTIRE LOOP):                                 
    # This subset contains general information about the parameters used in the
    #    execution of the while loop. It is only printed once at the 
    #    termination of the while loop.                  
    #                                                                
#     print("Starting Pixel Radius:", R)                             
#     print("Step Size:", dR,                                        
#           "\n------------------------------------------------|")   
    #                                                                
    # Angular range in which to check for potential anomalous data:  
#     print("Theta Check Range:", check_range)                       
    #                                                                
    # As the data 'zeros' are not actually 0, 1% of the smaller      
    #    of the absolute max and absolute min of the entire dataset  
    #    has been used to test for 'zeros': 
    #                         
#     print("Zero Constitution:", percentage_check)                  
    ###########################################################################
    
    ###########################################################################
    # All further statements with the exception of the return statement are 
    #    used to give information on the terminating loop for data collection. 
    #    Figures are generated that show the phi from the NSA Catalog, as well 
    #    as the pixels used from the H-alpha velocity field to generate the min 
    #    and max rotation curves. The caught, anomalous max and min for the 
    #    while loop are also printed to verify the algorithm is working 
    #    correctly.                          
    ###########################################################################
        
    ###########################################################################
    # Ha velocity field collected though all iterations of the loop.
    ###########################################################################
    vel_field_collected_fig = plt.figure( figsize=(5, 5))
    plt.title( file_id + " " + r'H$\alpha$ Velocity Field Collected')
    plt.imshow( vel_contour_plot, origin='lower', 
       vmin = -220, vmax=220, cmap='bwr')
    ax = vel_field_collected_fig.add_subplot(111)
    
    plt.xticks( np.arange( 0, 80, 10))
    plt.tick_params( axis='both', direction='in')
    ax.yaxis.set_ticks_position('both')
    ax.xaxis.set_ticks_position('both')
    plt.xlabel(r'$\Delta \alpha$ (arcsec)')
    plt.ylabel(r'$\Delta \delta$ (arcsec)')

    cbar = plt.colorbar( ticks = np.arange( -220, 221, 40))
    cbar.ax.tick_params( direction='in')
    cbar.set_label(r'$V_{ROT}$ [$kms^{-1}$]')

    ###########################################################################
    # Average luminosity as a function of deprojected radius.
    ###########################################################################
    lum_point_fig = plt.figure( figsize=(5, 5))
    plt.title( file_id + ' Average Luminosity vs Radius')
    plt.plot( rot_curve_dist, lum_curve_max, 'ro')
    plt.plot( rot_curve_dist, lum_curve_min, 'bo')
    plt.plot( rot_curve_dist, [lum_curve_max + lum_curve_min \
                               for lum_curve_max, lum_curve_min in \
                               zip(lum_curve_max, lum_curve_min)], 'go')
    ax = lum_point_fig.add_subplot(111)
    
    plt.tick_params( axis='both', direction='in')
    ax.yaxis.set_ticks_position('both')
    ax.xaxis.set_ticks_position('both')
    plt.xlabel('Radius [kpc]')
    plt.ylabel(r'Luminosity [$L_{\odot}$]')    
    
    ###########################################################################
    # Rotational velocity as a function of deprojected radius.
    ###########################################################################        
    rot_curve_fig = plt.figure( figsize=(5, 5))
    plt.title( file_id + ' Rotation Curves & Discrepancies')
    plt.plot( rot_curve_dist, rot_curve_max_vel, 'ro')
    plt.plot( rot_curve_dist, rot_curve_min_vel, 'bo')
    plt.plot( rot_curve_dist, rot_curve_vel_diff, 'g^')
    plt.plot( rot_curve_dist, rot_curve_vel_avg, 'm^')
    ax = rot_curve_fig.add_subplot(111)
    
    plt.tick_params( axis='both', direction='in')
    ax.yaxis.set_ticks_position('both')
    ax.xaxis.set_ticks_position('both')
    plt.xlabel('Deprojected Radius [kpc]')
    plt.ylabel('Rotational Velocity [km/s]')
    plt.show()
    ###########################################################################
    
    
    
    dist_col = Column( rot_curve_dist)
    max_vel_col = Column( rot_curve_max_vel)
    min_vel_col = Column( rot_curve_min_vel)
    max_lum_col = Column( lum_curve_max)
    min_lum_col = Column( lum_curve_min)
    lum_interior_col = Column( lum_interior)
    stellar_mass_interior_col = Column( stellar_mass_interior)
    
    lum_center_col = Column( [lum_center_sol])
    lum_processed_col = Column( [lum_processed])
    lum_unprocessed_col = Column( [lum_unprocessed])
    mass_processed_col = Column( [mass_processed])
    mass_unprocessed_col = Column( [mass_unprocessed])
    
    data_table = QTable([ dist_col *  u.kpc,
                          max_vel_col * ( u.km / u.s),
                          min_vel_col * ( u.km / u.s),
                          max_lum_col * (u.L_sun),
                          min_lum_col * (u.L_sun),
                          lum_interior_col * (u.L_sun),
                          stellar_mass_interior_col * (u.M_sun)],
                 names = ['deprojected_distance',
                          'max_velocity', 
                          'min_velocity',
                          'avg_luminosity_max',
                          'avg_luminosity_min',
                          'luminosity_interior',
                          'stellar_mass_interior'])
    
    gal_stats = QTable([ lum_center_col * u.L_sun,
                         lum_processed_col * u.L_sun,
                         lum_unprocessed_col * u.L_sun,
                         mass_processed_col * u.M_sun,
                         mass_unprocessed_col * u.M_sun],
                 names = ['center_luminosity',
                          'luminosity_processed',
                          'luminosity_unprocessed',
                          'mass_processed',
                          'mass_unprocessed'])

    return data_table, gal_stats           

def write_rot_curve( data_table, gal_stats, manga_plate, manga_fiberID,
                    LOCAL_PATH, ROT_CURVE_MASTER_FOLDER, 
                    ROT_CURVE_DATA_INDICATOR, GAL_STAT_DATA_INDICATOR):
    """Write data_table with an ascii-commented header to a .txt file 
    specified by the LOCAL_PATH, ROT_CURVE_MASTER_FOLDER, output_data_folder,
    output_data_name, and ROT_CURVE_DATA_INDICATOR variables.
     
    @param:        
        data_table:
            an astropy QTable containing the deprojected distance, maximum and 
            minimum velocities at that radius, average luminosities for each 
            half of the galaxy at that radius, luminosity interior to the 
            radius, and the stellar mass interior to the radius
            
        manga_plate:
            int representation of the manga plate number of observation
            
        manga_fiberID:
            int representation of the manga fiber ID of observation    
        
        gal_stats:
            an astropy QTable containing single valued columns of the processed
            and unprocessed luminosities and corresponding masses as well as 
            the luminosity at the center of the galaxy in question
        
        LOCAL_PATH: string specifying the path the main script is executed in
        
        ROT_CURVE_MASTER_FOLDER:
            name in which to store the data subfolders into
            
        ROT_CURVE_DATA_INDICATOR:
            the extension of the file before '.txt' that identifies the
            respective file as a rotation curve data file
            
        GAL_STAT_DATA_INDICATOR:
            the extension of the file before '.txt' that identifies the
            respective file as a galaxy statistics data file
    """        
    
    write_path = LOCAL_PATH + ROT_CURVE_MASTER_FOLDER + str( manga_plate) + '/'
    output_data_name = str( manga_plate) + '-' + str( manga_fiberID)
    
    if not os.path.exists( write_path):
        os.makedirs( write_path)
    
    ascii.write( data_table, write_path + output_data_name + \
                ROT_CURVE_DATA_INDICATOR + '.txt', 
                format = 'ecsv',
                overwrite = True)
    
    ascii.write( gal_stats, write_path + output_data_name + \
                GAL_STAT_DATA_INDICATOR + '.txt', 
                format = 'ecsv',
                overwrite = True)
    
def write_master_file( manga_plate_master, manga_fiberID_master, 
                       nsa_plate_master, nsa_fiberID_master, nsa_mjd_master,
                       nsa_gal_idx_master, 
                       nsa_axes_ratio_master, nsa_phi_master, nsa_zdist_master,
                       LOCAL_PATH):
    """Create the master file containing identifying information about each
    galaxy. The output file of this function determines the structure of the
    master file that will contain the best fit parameters for the fitted
    rotation curve equations.
    
    @param:
        manga_plate_master:
            master list containing the MaNGA plate information for each galaxy
            
        manga_fiberID_master:
            master list containing the MaNGA fiber ID information for each
            galaxy
            
        nsa_plate_master:
            master list containing the NSA plate information for each galaxy
            
        nsa_fiberID_master:
            master list containing the NSA fiber ID information for each galaxy
            
        nsa_mjd_master:
            master list containing the NSA MJD information for each galaxy
            
        nsa_gal_idx_master:
            master list containing the matched index for each galaxy as
            calculated through the 'match' function above
            
        nsa_axes_ratio_master:
            master list containing all the axes ratios used in extracting the
            rotation curve
            
        nsa_phi_master:
            master list containing all the rotation angles of the galaxies used
            in extracting the rotation curve
            
        nsa_zdist_master:
            master list containing all the redshift distances of the galaxies
            used in extracting the rotation curve
            
        LOCAL_PATH:
            the directory path of the main script file
    """
    write_path = LOCAL_PATH + '/'
    output_data_name = 'master_file.txt'
    
    manga_plate_col = Column( manga_plate_master)
    manga_fiberID_col = Column( manga_fiberID_master)
    nsa_plate_col = Column( nsa_plate_master)
    nsa_fiberID_col = Column( nsa_fiberID_master)
    nsa_mjd_col = Column( nsa_mjd_master)
    nsa_gal_idx_col = Column( nsa_gal_idx_master)
    nsa_axes_ratio_col = Column( nsa_axes_ratio_master)
    nsa_phi_col = Column( nsa_phi_master)
    nsa_zdist_col = Column( nsa_zdist_master)
    
    
    master_table = QTable([ manga_plate_col,
                            manga_fiberID_col,
                            nsa_plate_col,
                            nsa_fiberID_col,
                            nsa_mjd_col,
                            nsa_gal_idx_col,
                            nsa_axes_ratio_col,
                            nsa_phi_col * u.degree,
                            nsa_zdist_col],
                   names = ['MaNGA_plate',
                            'MaNGA_fiberID', 
                            'NSA_plate',
                            'NSA_fiberID',
                            'NSA_MJD',
                            'NSA_index',
                            'NSA_b/a',
                            'NSA_phi',
                            'NSA_zdist'])
    
    ascii.write( master_table, write_path + output_data_name, 
                format = 'ecsv',
                overwrite = True)    